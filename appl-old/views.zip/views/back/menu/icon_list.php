<div class="doc icons-doc page-layout simple full-width">
<div class="content container">
                                <div class="row">

                                    <div class="col-12 mb-12">
                                        <div class="row icons">

                                            <div>
                                                <i class="icon-access-point-network"></i>
                                                <div class="mt-8">icon-access-point-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-access-point"></i>
                                                <div class="mt-8">icon-access-point</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-alert"></i>
                                                <div class="mt-8">icon-account-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-box-outline"></i>
                                                <div class="mt-8">icon-account-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-box"></i>
                                                <div class="mt-8">icon-account-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-card-details"></i>
                                                <div class="mt-8">icon-account-card-details</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-check"></i>
                                                <div class="mt-8">icon-account-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-circle"></i>
                                                <div class="mt-8">icon-account-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-convert"></i>
                                                <div class="mt-8">icon-account-convert</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-edit"></i>
                                                <div class="mt-8">icon-account-edit</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-key"></i>
                                                <div class="mt-8">icon-account-key</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-location"></i>
                                                <div class="mt-8">icon-account-location</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-minus"></i>
                                                <div class="mt-8">icon-account-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-multiple-minus"></i>
                                                <div class="mt-8">icon-account-multiple-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-multiple-outline"></i>
                                                <div class="mt-8">icon-account-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-multiple-plus"></i>
                                                <div class="mt-8">icon-account-multiple-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-multiple"></i>
                                                <div class="mt-8">icon-account-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-network"></i>
                                                <div class="mt-8">icon-account-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-off"></i>
                                                <div class="mt-8">icon-account-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-outline"></i>
                                                <div class="mt-8">icon-account-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-plus"></i>
                                                <div class="mt-8">icon-account-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-remove"></i>
                                                <div class="mt-8">icon-account-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-search"></i>
                                                <div class="mt-8">icon-account-search</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-settings-variant"></i>
                                                <div class="mt-8">icon-account-settings-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-settings"></i>
                                                <div class="mt-8">icon-account-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-account-switch"></i>
                                                <div class="mt-8">icon-account-switch</div>
                                            </div>

                                            <div>
                                                <i class="icon-account"></i>
                                                <div class="mt-8">icon-account</div>
                                            </div>

                                            <div>
                                                <i class="icon-adjust"></i>
                                                <div class="mt-8">icon-adjust</div>
                                            </div>

                                            <div>
                                                <i class="icon-air-conditioner"></i>
                                                <div class="mt-8">icon-air-conditioner</div>
                                            </div>

                                            <div>
                                                <i class="icon-airballoon"></i>
                                                <div class="mt-8">icon-airballoon</div>
                                            </div>

                                            <div>
                                                <i class="icon-airplane-landing"></i>
                                                <div class="mt-8">icon-airplane-landing</div>
                                            </div>

                                            <div>
                                                <i class="icon-airplane-off"></i>
                                                <div class="mt-8">icon-airplane-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-airplane-takeoff"></i>
                                                <div class="mt-8">icon-airplane-takeoff</div>
                                            </div>

                                            <div>
                                                <i class="icon-airplane"></i>
                                                <div class="mt-8">icon-airplane</div>
                                            </div>

                                            <div>
                                                <i class="icon-airplay"></i>
                                                <div class="mt-8">icon-airplay</div>
                                            </div>

                                            <div>
                                                <i class="icon-alarm-check"></i>
                                                <div class="mt-8">icon-alarm-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-alarm-multiple"></i>
                                                <div class="mt-8">icon-alarm-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-alarm-off"></i>
                                                <div class="mt-8">icon-alarm-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-alarm-plus"></i>
                                                <div class="mt-8">icon-alarm-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-alarm-snooze"></i>
                                                <div class="mt-8">icon-alarm-snooze</div>
                                            </div>

                                            <div>
                                                <i class="icon-alarm"></i>
                                                <div class="mt-8">icon-alarm</div>
                                            </div>

                                            <div>
                                                <i class="icon-album"></i>
                                                <div class="mt-8">icon-album</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert-box"></i>
                                                <div class="mt-8">icon-alert-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert-circle-outline"></i>
                                                <div class="mt-8">icon-alert-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert-circle"></i>
                                                <div class="mt-8">icon-alert-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert-decagram"></i>
                                                <div class="mt-8">icon-alert-decagram</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert-octagon"></i>
                                                <div class="mt-8">icon-alert-octagon</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert-octagram"></i>
                                                <div class="mt-8">icon-alert-octagram</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert-outline"></i>
                                                <div class="mt-8">icon-alert-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-alert"></i>
                                                <div class="mt-8">icon-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-all-inclusive"></i>
                                                <div class="mt-8">icon-all-inclusive</div>
                                            </div>

                                            <div>
                                                <i class="icon-alpha"></i>
                                                <div class="mt-8">icon-alpha</div>
                                            </div>

                                            <div>
                                                <i class="icon-alphabetical"></i>
                                                <div class="mt-8">icon-alphabetical</div>
                                            </div>

                                            <div>
                                                <i class="icon-altimeter"></i>
                                                <div class="mt-8">icon-altimeter</div>
                                            </div>

                                            <div>
                                                <i class="icon-amazon-clouddrive"></i>
                                                <div class="mt-8">icon-amazon-clouddrive</div>
                                            </div>

                                            <div>
                                                <i class="icon-amazon"></i>
                                                <div class="mt-8">icon-amazon</div>
                                            </div>

                                            <div>
                                                <i class="icon-ambulance"></i>
                                                <div class="mt-8">icon-ambulance</div>
                                            </div>

                                            <div>
                                                <i class="icon-amplifier"></i>
                                                <div class="mt-8">icon-amplifier</div>
                                            </div>

                                            <div>
                                                <i class="icon-anchor"></i>
                                                <div class="mt-8">icon-anchor</div>
                                            </div>

                                            <div>
                                                <i class="icon-android-debug-bridge"></i>
                                                <div class="mt-8">icon-android-debug-bridge</div>
                                            </div>

                                            <div>
                                                <i class="icon-android-studio"></i>
                                                <div class="mt-8">icon-android-studio</div>
                                            </div>

                                            <div>
                                                <i class="icon-android"></i>
                                                <div class="mt-8">icon-android</div>
                                            </div>

                                            <div>
                                                <i class="icon-angular"></i>
                                                <div class="mt-8">icon-angular</div>
                                            </div>

                                            <div>
                                                <i class="icon-angularjs"></i>
                                                <div class="mt-8">icon-angularjs</div>
                                            </div>

                                            <div>
                                                <i class="icon-animation"></i>
                                                <div class="mt-8">icon-animation</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-finder"></i>
                                                <div class="mt-8">icon-apple-finder</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-ios"></i>
                                                <div class="mt-8">icon-apple-ios</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-keyboard-caps"></i>
                                                <div class="mt-8">icon-apple-keyboard-caps</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-keyboard-command"></i>
                                                <div class="mt-8">icon-apple-keyboard-command</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-keyboard-control"></i>
                                                <div class="mt-8">icon-apple-keyboard-control</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-keyboard-option"></i>
                                                <div class="mt-8">icon-apple-keyboard-option</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-keyboard-shift"></i>
                                                <div class="mt-8">icon-apple-keyboard-shift</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-mobileme"></i>
                                                <div class="mt-8">icon-apple-mobileme</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple-safari"></i>
                                                <div class="mt-8">icon-apple-safari</div>
                                            </div>

                                            <div>
                                                <i class="icon-apple"></i>
                                                <div class="mt-8">icon-apple</div>
                                            </div>

                                            <div>
                                                <i class="icon-application"></i>
                                                <div class="mt-8">icon-application</div>
                                            </div>

                                            <div>
                                                <i class="icon-appnet"></i>
                                                <div class="mt-8">icon-appnet</div>
                                            </div>

                                            <div>
                                                <i class="icon-apps"></i>
                                                <div class="mt-8">icon-apps</div>
                                            </div>

                                            <div>
                                                <i class="icon-archive"></i>
                                                <div class="mt-8">icon-archive</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrange-bring-forward"></i>
                                                <div class="mt-8">icon-arrange-bring-forward</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrange-bring-to-front"></i>
                                                <div class="mt-8">icon-arrange-bring-to-front</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrange-send-backward"></i>
                                                <div class="mt-8">icon-arrange-send-backward</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrange-send-to-back"></i>
                                                <div class="mt-8">icon-arrange-send-to-back</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-all"></i>
                                                <div class="mt-8">icon-arrow-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-bottom-left"></i>
                                                <div class="mt-8">icon-arrow-bottom-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-bottom-right"></i>
                                                <div class="mt-8">icon-arrow-bottom-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-compress-all"></i>
                                                <div class="mt-8">icon-arrow-compress-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-compress"></i>
                                                <div class="mt-8">icon-arrow-compress</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-bold-box-outline"></i>
                                                <div class="mt-8">icon-arrow-down-bold-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-bold-box"></i>
                                                <div class="mt-8">icon-arrow-down-bold-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-bold-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-down-bold-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-bold-circle"></i>
                                                <div class="mt-8">icon-arrow-down-bold-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-bold-hexagon-outline"></i>
                                                <div class="mt-8">icon-arrow-down-bold-hexagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-bold"></i>
                                                <div class="mt-8">icon-arrow-down-bold</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-box"></i>
                                                <div class="mt-8">icon-arrow-down-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-drop-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-down-drop-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-drop-circle"></i>
                                                <div class="mt-8">icon-arrow-down-drop-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-drop"></i>
                                                <div class="mt-8">icon-arrow-down-drop</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down-thick"></i>
                                                <div class="mt-8">icon-arrow-down-thick</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-down"></i>
                                                <div class="mt-8">icon-arrow-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-expand-all"></i>
                                                <div class="mt-8">icon-arrow-expand-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-expand"></i>
                                                <div class="mt-8">icon-arrow-expand</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-bold-box-outline"></i>
                                                <div class="mt-8">icon-arrow-left-bold-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-bold-box"></i>
                                                <div class="mt-8">icon-arrow-left-bold-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-bold-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-left-bold-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-bold-circle"></i>
                                                <div class="mt-8">icon-arrow-left-bold-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-bold-hexagon-outline"></i>
                                                <div class="mt-8">icon-arrow-left-bold-hexagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-bold"></i>
                                                <div class="mt-8">icon-arrow-left-bold</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-box"></i>
                                                <div class="mt-8">icon-arrow-left-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-drop-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-left-drop-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-drop-circle"></i>
                                                <div class="mt-8">icon-arrow-left-drop-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left-thick"></i>
                                                <div class="mt-8">icon-arrow-left-thick</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-left"></i>
                                                <div class="mt-8">icon-arrow-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-bold-box-outline"></i>
                                                <div class="mt-8">icon-arrow-right-bold-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-bold-box"></i>
                                                <div class="mt-8">icon-arrow-right-bold-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-bold-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-right-bold-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-bold-circle"></i>
                                                <div class="mt-8">icon-arrow-right-bold-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-bold-hexagon-outline"></i>
                                                <div class="mt-8">icon-arrow-right-bold-hexagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-bold"></i>
                                                <div class="mt-8">icon-arrow-right-bold</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-box"></i>
                                                <div class="mt-8">icon-arrow-right-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-drop-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-right-drop-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-drop-circle"></i>
                                                <div class="mt-8">icon-arrow-right-drop-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right-thick"></i>
                                                <div class="mt-8">icon-arrow-right-thick</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-right"></i>
                                                <div class="mt-8">icon-arrow-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-top-left"></i>
                                                <div class="mt-8">icon-arrow-top-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-top-right"></i>
                                                <div class="mt-8">icon-arrow-top-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-bold-box-outline"></i>
                                                <div class="mt-8">icon-arrow-up-bold-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-bold-box"></i>
                                                <div class="mt-8">icon-arrow-up-bold-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-bold-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-up-bold-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-bold-circle"></i>
                                                <div class="mt-8">icon-arrow-up-bold-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-bold-hexagon-outline"></i>
                                                <div class="mt-8">icon-arrow-up-bold-hexagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-bold"></i>
                                                <div class="mt-8">icon-arrow-up-bold</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-box"></i>
                                                <div class="mt-8">icon-arrow-up-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-drop-circle-outline"></i>
                                                <div class="mt-8">icon-arrow-up-drop-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-drop-circle"></i>
                                                <div class="mt-8">icon-arrow-up-drop-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up-thick"></i>
                                                <div class="mt-8">icon-arrow-up-thick</div>
                                            </div>

                                            <div>
                                                <i class="icon-arrow-up"></i>
                                                <div class="mt-8">icon-arrow-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-assistant"></i>
                                                <div class="mt-8">icon-assistant</div>
                                            </div>

                                            <div>
                                                <i class="icon-asterisk"></i>
                                                <div class="mt-8">icon-asterisk</div>
                                            </div>

                                            <div>
                                                <i class="icon-at"></i>
                                                <div class="mt-8">icon-at</div>
                                            </div>

                                            <div>
                                                <i class="icon-atom"></i>
                                                <div class="mt-8">icon-atom</div>
                                            </div>

                                            <div>
                                                <i class="icon-attachment"></i>
                                                <div class="mt-8">icon-attachment</div>
                                            </div>

                                            <div>
                                                <i class="icon-audiobook"></i>
                                                <div class="mt-8">icon-audiobook</div>
                                            </div>

                                            <div>
                                                <i class="icon-auto-fix"></i>
                                                <div class="mt-8">icon-auto-fix</div>
                                            </div>

                                            <div>
                                                <i class="icon-auto-upload"></i>
                                                <div class="mt-8">icon-auto-upload</div>
                                            </div>

                                            <div>
                                                <i class="icon-autorenew"></i>
                                                <div class="mt-8">icon-autorenew</div>
                                            </div>

                                            <div>
                                                <i class="icon-av-timer"></i>
                                                <div class="mt-8">icon-av-timer</div>
                                            </div>

                                            <div>
                                                <i class="icon-baby-buggy"></i>
                                                <div class="mt-8">icon-baby-buggy</div>
                                            </div>

                                            <div>
                                                <i class="icon-baby"></i>
                                                <div class="mt-8">icon-baby</div>
                                            </div>

                                            <div>
                                                <i class="icon-backburger"></i>
                                                <div class="mt-8">icon-backburger</div>
                                            </div>

                                            <div>
                                                <i class="icon-backspace"></i>
                                                <div class="mt-8">icon-backspace</div>
                                            </div>

                                            <div>
                                                <i class="icon-backup-restore"></i>
                                                <div class="mt-8">icon-backup-restore</div>
                                            </div>

                                            <div>
                                                <i class="icon-bandcamp"></i>
                                                <div class="mt-8">icon-bandcamp</div>
                                            </div>

                                            <div>
                                                <i class="icon-bank"></i>
                                                <div class="mt-8">icon-bank</div>
                                            </div>

                                            <div>
                                                <i class="icon-barcode-scan"></i>
                                                <div class="mt-8">icon-barcode-scan</div>
                                            </div>

                                            <div>
                                                <i class="icon-barcode"></i>
                                                <div class="mt-8">icon-barcode</div>
                                            </div>

                                            <div>
                                                <i class="icon-barley"></i>
                                                <div class="mt-8">icon-barley</div>
                                            </div>

                                            <div>
                                                <i class="icon-barrel"></i>
                                                <div class="mt-8">icon-barrel</div>
                                            </div>

                                            <div>
                                                <i class="icon-basecamp"></i>
                                                <div class="mt-8">icon-basecamp</div>
                                            </div>

                                            <div>
                                                <i class="icon-basket-fill"></i>
                                                <div class="mt-8">icon-basket-fill</div>
                                            </div>

                                            <div>
                                                <i class="icon-basket-unfill"></i>
                                                <div class="mt-8">icon-basket-unfill</div>
                                            </div>

                                            <div>
                                                <i class="icon-basket"></i>
                                                <div class="mt-8">icon-basket</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-10"></i>
                                                <div class="mt-8">icon-battery-10</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-20"></i>
                                                <div class="mt-8">icon-battery-20</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-30"></i>
                                                <div class="mt-8">icon-battery-30</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-40"></i>
                                                <div class="mt-8">icon-battery-40</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-50"></i>
                                                <div class="mt-8">icon-battery-50</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-60"></i>
                                                <div class="mt-8">icon-battery-60</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-70"></i>
                                                <div class="mt-8">icon-battery-70</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-80"></i>
                                                <div class="mt-8">icon-battery-80</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-90"></i>
                                                <div class="mt-8">icon-battery-90</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-alert"></i>
                                                <div class="mt-8">icon-battery-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging-20"></i>
                                                <div class="mt-8">icon-battery-charging-20</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging-30"></i>
                                                <div class="mt-8">icon-battery-charging-30</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging-40"></i>
                                                <div class="mt-8">icon-battery-charging-40</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging-60"></i>
                                                <div class="mt-8">icon-battery-charging-60</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging-80"></i>
                                                <div class="mt-8">icon-battery-charging-80</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging-90"></i>
                                                <div class="mt-8">icon-battery-charging-90</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging-100"></i>
                                                <div class="mt-8">icon-battery-charging-100</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-charging"></i>
                                                <div class="mt-8">icon-battery-charging</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-minus"></i>
                                                <div class="mt-8">icon-battery-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-negative"></i>
                                                <div class="mt-8">icon-battery-negative</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-outline"></i>
                                                <div class="mt-8">icon-battery-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-plus"></i>
                                                <div class="mt-8">icon-battery-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-positive"></i>
                                                <div class="mt-8">icon-battery-positive</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-standard"></i>
                                                <div class="mt-8">icon-battery-standard</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery-unknown"></i>
                                                <div class="mt-8">icon-battery-unknown</div>
                                            </div>

                                            <div>
                                                <i class="icon-battery"></i>
                                                <div class="mt-8">icon-battery</div>
                                            </div>

                                            <div>
                                                <i class="icon-beach"></i>
                                                <div class="mt-8">icon-beach</div>
                                            </div>

                                            <div>
                                                <i class="icon-beaker"></i>
                                                <div class="mt-8">icon-beaker</div>
                                            </div>

                                            <div>
                                                <i class="icon-beats"></i>
                                                <div class="mt-8">icon-beats</div>
                                            </div>

                                            <div>
                                                <i class="icon-beer"></i>
                                                <div class="mt-8">icon-beer</div>
                                            </div>

                                            <div>
                                                <i class="icon-behance"></i>
                                                <div class="mt-8">icon-behance</div>
                                            </div>

                                            <div>
                                                <i class="icon-bell-off"></i>
                                                <div class="mt-8">icon-bell-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-bell-outline"></i>
                                                <div class="mt-8">icon-bell-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-bell-plus"></i>
                                                <div class="mt-8">icon-bell-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-bell-ring-outline"></i>
                                                <div class="mt-8">icon-bell-ring-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-bell-ring"></i>
                                                <div class="mt-8">icon-bell-ring</div>
                                            </div>

                                            <div>
                                                <i class="icon-bell-sleep"></i>
                                                <div class="mt-8">icon-bell-sleep</div>
                                            </div>

                                            <div>
                                                <i class="icon-bell"></i>
                                                <div class="mt-8">icon-bell</div>
                                            </div>

                                            <div>
                                                <i class="icon-beta"></i>
                                                <div class="mt-8">icon-beta</div>
                                            </div>

                                            <div>
                                                <i class="icon-bible"></i>
                                                <div class="mt-8">icon-bible</div>
                                            </div>

                                            <div>
                                                <i class="icon-bike"></i>
                                                <div class="mt-8">icon-bike</div>
                                            </div>

                                            <div>
                                                <i class="icon-bing"></i>
                                                <div class="mt-8">icon-bing</div>
                                            </div>

                                            <div>
                                                <i class="icon-binoculars"></i>
                                                <div class="mt-8">icon-binoculars</div>
                                            </div>

                                            <div>
                                                <i class="icon-bio"></i>
                                                <div class="mt-8">icon-bio</div>
                                            </div>

                                            <div>
                                                <i class="icon-bitbucket"></i>
                                                <div class="mt-8">icon-bitbucket</div>
                                            </div>

                                            <div>
                                                <i class="icon-black-mesa"></i>
                                                <div class="mt-8">icon-black-mesa</div>
                                            </div>

                                            <div>
                                                <i class="icon-blackberry"></i>
                                                <div class="mt-8">icon-blackberry</div>
                                            </div>

                                            <div>
                                                <i class="icon-blender"></i>
                                                <div class="mt-8">icon-blender</div>
                                            </div>

                                            <div>
                                                <i class="icon-blinds"></i>
                                                <div class="mt-8">icon-blinds</div>
                                            </div>

                                            <div>
                                                <i class="icon-block-helper"></i>
                                                <div class="mt-8">icon-block-helper</div>
                                            </div>

                                            <div>
                                                <i class="icon-blogger"></i>
                                                <div class="mt-8">icon-blogger</div>
                                            </div>

                                            <div>
                                                <i class="icon-bluetooth-audio"></i>
                                                <div class="mt-8">icon-bluetooth-audio</div>
                                            </div>

                                            <div>
                                                <i class="icon-bluetooth-connect"></i>
                                                <div class="mt-8">icon-bluetooth-connect</div>
                                            </div>

                                            <div>
                                                <i class="icon-bluetooth-off"></i>
                                                <div class="mt-8">icon-bluetooth-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-bluetooth-settings"></i>
                                                <div class="mt-8">icon-bluetooth-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-bluetooth-transfer"></i>
                                                <div class="mt-8">icon-bluetooth-transfer</div>
                                            </div>

                                            <div>
                                                <i class="icon-bluetooth"></i>
                                                <div class="mt-8">icon-bluetooth</div>
                                            </div>

                                            <div>
                                                <i class="icon-blur-linear"></i>
                                                <div class="mt-8">icon-blur-linear</div>
                                            </div>

                                            <div>
                                                <i class="icon-blur-off"></i>
                                                <div class="mt-8">icon-blur-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-blur-radial"></i>
                                                <div class="mt-8">icon-blur-radial</div>
                                            </div>

                                            <div>
                                                <i class="icon-blur"></i>
                                                <div class="mt-8">icon-blur</div>
                                            </div>

                                            <div>
                                                <i class="icon-bomb-off"></i>
                                                <div class="mt-8">icon-bomb-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-bomb"></i>
                                                <div class="mt-8">icon-bomb</div>
                                            </div>

                                            <div>
                                                <i class="icon-bone"></i>
                                                <div class="mt-8">icon-bone</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-minus"></i>
                                                <div class="mt-8">icon-book-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-multiple-variant"></i>
                                                <div class="mt-8">icon-book-multiple-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-multiple"></i>
                                                <div class="mt-8">icon-book-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-open-page-variant"></i>
                                                <div class="mt-8">icon-book-open-page-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-open-variant"></i>
                                                <div class="mt-8">icon-book-open-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-open"></i>
                                                <div class="mt-8">icon-book-open</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-plus"></i>
                                                <div class="mt-8">icon-book-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-book-variant"></i>
                                                <div class="mt-8">icon-book-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-book"></i>
                                                <div class="mt-8">icon-book</div>
                                            </div>

                                            <div>
                                                <i class="icon-bookmark-check"></i>
                                                <div class="mt-8">icon-bookmark-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-bookmark-music"></i>
                                                <div class="mt-8">icon-bookmark-music</div>
                                            </div>

                                            <div>
                                                <i class="icon-bookmark-outline-plus"></i>
                                                <div class="mt-8">icon-bookmark-outline-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-bookmark-outline"></i>
                                                <div class="mt-8">icon-bookmark-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-bookmark-plus"></i>
                                                <div class="mt-8">icon-bookmark-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-bookmark-remove"></i>
                                                <div class="mt-8">icon-bookmark-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-bookmark"></i>
                                                <div class="mt-8">icon-bookmark</div>
                                            </div>

                                            <div>
                                                <i class="icon-boombox"></i>
                                                <div class="mt-8">icon-boombox</div>
                                            </div>

                                            <div>
                                                <i class="icon-bootstrap"></i>
                                                <div class="mt-8">icon-bootstrap</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-all"></i>
                                                <div class="mt-8">icon-border-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-bottom"></i>
                                                <div class="mt-8">icon-border-bottom</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-color"></i>
                                                <div class="mt-8">icon-border-color</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-horizontal"></i>
                                                <div class="mt-8">icon-border-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-inside"></i>
                                                <div class="mt-8">icon-border-inside</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-left"></i>
                                                <div class="mt-8">icon-border-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-none"></i>
                                                <div class="mt-8">icon-border-none</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-outside"></i>
                                                <div class="mt-8">icon-border-outside</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-right"></i>
                                                <div class="mt-8">icon-border-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-style"></i>
                                                <div class="mt-8">icon-border-style</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-top"></i>
                                                <div class="mt-8">icon-border-top</div>
                                            </div>

                                            <div>
                                                <i class="icon-border-vertical"></i>
                                                <div class="mt-8">icon-border-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-bow-tie"></i>
                                                <div class="mt-8">icon-bow-tie</div>
                                            </div>

                                            <div>
                                                <i class="icon-bowl"></i>
                                                <div class="mt-8">icon-bowl</div>
                                            </div>

                                            <div>
                                                <i class="icon-bowling"></i>
                                                <div class="mt-8">icon-bowling</div>
                                            </div>

                                            <div>
                                                <i class="icon-box-cutter"></i>
                                                <div class="mt-8">icon-box-cutter</div>
                                            </div>

                                            <div>
                                                <i class="icon-box-download"></i>
                                                <div class="mt-8">icon-box-download</div>
                                            </div>

                                            <div>
                                                <i class="icon-box-shadow"></i>
                                                <div class="mt-8">icon-box-shadow</div>
                                            </div>

                                            <div>
                                                <i class="icon-box-upload"></i>
                                                <div class="mt-8">icon-box-upload</div>
                                            </div>

                                            <div>
                                                <i class="icon-box"></i>
                                                <div class="mt-8">icon-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-bridge"></i>
                                                <div class="mt-8">icon-bridge</div>
                                            </div>

                                            <div>
                                                <i class="icon-briefcase-checked"></i>
                                                <div class="mt-8">icon-briefcase-checked</div>
                                            </div>

                                            <div>
                                                <i class="icon-briefcase-download"></i>
                                                <div class="mt-8">icon-briefcase-download</div>
                                            </div>

                                            <div>
                                                <i class="icon-briefcase-upload"></i>
                                                <div class="mt-8">icon-briefcase-upload</div>
                                            </div>

                                            <div>
                                                <i class="icon-briefcase"></i>
                                                <div class="mt-8">icon-briefcase</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-1"></i>
                                                <div class="mt-8">icon-brightness-1</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-2"></i>
                                                <div class="mt-8">icon-brightness-2</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-3"></i>
                                                <div class="mt-8">icon-brightness-3</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-4"></i>
                                                <div class="mt-8">icon-brightness-4</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-5"></i>
                                                <div class="mt-8">icon-brightness-5</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-6"></i>
                                                <div class="mt-8">icon-brightness-6</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-7"></i>
                                                <div class="mt-8">icon-brightness-7</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness-auto"></i>
                                                <div class="mt-8">icon-brightness-auto</div>
                                            </div>

                                            <div>
                                                <i class="icon-brightness"></i>
                                                <div class="mt-8">icon-brightness</div>
                                            </div>

                                            <div>
                                                <i class="icon-broom"></i>
                                                <div class="mt-8">icon-broom</div>
                                            </div>

                                            <div>
                                                <i class="icon-brush"></i>
                                                <div class="mt-8">icon-brush</div>
                                            </div>

                                            <div>
                                                <i class="icon-buffer"></i>
                                                <div class="mt-8">icon-buffer</div>
                                            </div>

                                            <div>
                                                <i class="icon-bug"></i>
                                                <div class="mt-8">icon-bug</div>
                                            </div>

                                            <div>
                                                <i class="icon-bulletin-board"></i>
                                                <div class="mt-8">icon-bulletin-board</div>
                                            </div>

                                            <div>
                                                <i class="icon-bullhorn"></i>
                                                <div class="mt-8">icon-bullhorn</div>
                                            </div>

                                            <div>
                                                <i class="icon-bullseye"></i>
                                                <div class="mt-8">icon-bullseye</div>
                                            </div>

                                            <div>
                                                <i class="icon-burst-mode"></i>
                                                <div class="mt-8">icon-burst-mode</div>
                                            </div>

                                            <div>
                                                <i class="icon-bus"></i>
                                                <div class="mt-8">icon-bus</div>
                                            </div>

                                            <div>
                                                <i class="icon-cached"></i>
                                                <div class="mt-8">icon-cached</div>
                                            </div>

                                            <div>
                                                <i class="icon-cake-layered"></i>
                                                <div class="mt-8">icon-cake-layered</div>
                                            </div>

                                            <div>
                                                <i class="icon-cake-variant"></i>
                                                <div class="mt-8">icon-cake-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-cake"></i>
                                                <div class="mt-8">icon-cake</div>
                                            </div>

                                            <div>
                                                <i class="icon-calculator-off"></i>
                                                <div class="mt-8">icon-calculator-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-calculator"></i>
                                                <div class="mt-8">icon-calculator</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-blank"></i>
                                                <div class="mt-8">icon-calendar-blank</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-check-multiple"></i>
                                                <div class="mt-8">icon-calendar-check-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-check"></i>
                                                <div class="mt-8">icon-calendar-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-clock"></i>
                                                <div class="mt-8">icon-calendar-clock</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-multiple"></i>
                                                <div class="mt-8">icon-calendar-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-plus"></i>
                                                <div class="mt-8">icon-calendar-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-question"></i>
                                                <div class="mt-8">icon-calendar-question</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-range"></i>
                                                <div class="mt-8">icon-calendar-range</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-remove"></i>
                                                <div class="mt-8">icon-calendar-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-select"></i>
                                                <div class="mt-8">icon-calendar-select</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-text"></i>
                                                <div class="mt-8">icon-calendar-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar-today"></i>
                                                <div class="mt-8">icon-calendar-today</div>
                                            </div>

                                            <div>
                                                <i class="icon-calendar"></i>
                                                <div class="mt-8">icon-calendar</div>
                                            </div>

                                            <div>
                                                <i class="icon-call-made"></i>
                                                <div class="mt-8">icon-call-made</div>
                                            </div>

                                            <div>
                                                <i class="icon-call-merge"></i>
                                                <div class="mt-8">icon-call-merge</div>
                                            </div>

                                            <div>
                                                <i class="icon-call-missed"></i>
                                                <div class="mt-8">icon-call-missed</div>
                                            </div>

                                            <div>
                                                <i class="icon-call-received"></i>
                                                <div class="mt-8">icon-call-received</div>
                                            </div>

                                            <div>
                                                <i class="icon-call-split"></i>
                                                <div class="mt-8">icon-call-split</div>
                                            </div>

                                            <div>
                                                <i class="icon-camcorder-box-off"></i>
                                                <div class="mt-8">icon-camcorder-box-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-camcorder-box"></i>
                                                <div class="mt-8">icon-camcorder-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-camcorder-off"></i>
                                                <div class="mt-8">icon-camcorder-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-camcorder"></i>
                                                <div class="mt-8">icon-camcorder</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-burst"></i>
                                                <div class="mt-8">icon-camera-burst</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-enhance"></i>
                                                <div class="mt-8">icon-camera-enhance</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-front-variant"></i>
                                                <div class="mt-8">icon-camera-front-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-front"></i>
                                                <div class="mt-8">icon-camera-front</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-iris"></i>
                                                <div class="mt-8">icon-camera-iris</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-off"></i>
                                                <div class="mt-8">icon-camera-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-party-mode"></i>
                                                <div class="mt-8">icon-camera-party-mode</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-rear-variant"></i>
                                                <div class="mt-8">icon-camera-rear-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-rear"></i>
                                                <div class="mt-8">icon-camera-rear</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-switch"></i>
                                                <div class="mt-8">icon-camera-switch</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera-timer"></i>
                                                <div class="mt-8">icon-camera-timer</div>
                                            </div>

                                            <div>
                                                <i class="icon-camera"></i>
                                                <div class="mt-8">icon-camera</div>
                                            </div>

                                            <div>
                                                <i class="icon-cancel"></i>
                                                <div class="mt-8">icon-cancel</div>
                                            </div>

                                            <div>
                                                <i class="icon-candle"></i>
                                                <div class="mt-8">icon-candle</div>
                                            </div>

                                            <div>
                                                <i class="icon-candycane"></i>
                                                <div class="mt-8">icon-candycane</div>
                                            </div>

                                            <div>
                                                <i class="icon-car-battery"></i>
                                                <div class="mt-8">icon-car-battery</div>
                                            </div>

                                            <div>
                                                <i class="icon-car-connected"></i>
                                                <div class="mt-8">icon-car-connected</div>
                                            </div>

                                            <div>
                                                <i class="icon-car-wash"></i>
                                                <div class="mt-8">icon-car-wash</div>
                                            </div>

                                            <div>
                                                <i class="icon-car"></i>
                                                <div class="mt-8">icon-car</div>
                                            </div>

                                            <div>
                                                <i class="icon-cards-outline"></i>
                                                <div class="mt-8">icon-cards-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-cards-playing-outline"></i>
                                                <div class="mt-8">icon-cards-playing-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-cards-variant"></i>
                                                <div class="mt-8">icon-cards-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-cards"></i>
                                                <div class="mt-8">icon-cards</div>
                                            </div>

                                            <div>
                                                <i class="icon-carrot"></i>
                                                <div class="mt-8">icon-carrot</div>
                                            </div>

                                            <div>
                                                <i class="icon-cart-off"></i>
                                                <div class="mt-8">icon-cart-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-cart-outline"></i>
                                                <div class="mt-8">icon-cart-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-cart-plus"></i>
                                                <div class="mt-8">icon-cart-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-cart"></i>
                                                <div class="mt-8">icon-cart</div>
                                            </div>

                                            <div>
                                                <i class="icon-cash-100"></i>
                                                <div class="mt-8">icon-cash-100</div>
                                            </div>

                                            <div>
                                                <i class="icon-cash-multiple"></i>
                                                <div class="mt-8">icon-cash-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-cash-usd"></i>
                                                <div class="mt-8">icon-cash-usd</div>
                                            </div>

                                            <div>
                                                <i class="icon-cash"></i>
                                                <div class="mt-8">icon-cash</div>
                                            </div>

                                            <div>
                                                <i class="icon-cast-connected"></i>
                                                <div class="mt-8">icon-cast-connected</div>
                                            </div>

                                            <div>
                                                <i class="icon-cast-off"></i>
                                                <div class="mt-8">icon-cast-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-cast"></i>
                                                <div class="mt-8">icon-cast</div>
                                            </div>

                                            <div>
                                                <i class="icon-castle"></i>
                                                <div class="mt-8">icon-castle</div>
                                            </div>

                                            <div>
                                                <i class="icon-cat"></i>
                                                <div class="mt-8">icon-cat</div>
                                            </div>

                                            <div>
                                                <i class="icon-ceiling-light"></i>
                                                <div class="mt-8">icon-ceiling-light</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone-android"></i>
                                                <div class="mt-8">icon-cellphone-android</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone-basic"></i>
                                                <div class="mt-8">icon-cellphone-basic</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone-dock"></i>
                                                <div class="mt-8">icon-cellphone-dock</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone-iphone"></i>
                                                <div class="mt-8">icon-cellphone-iphone</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone-link-off"></i>
                                                <div class="mt-8">icon-cellphone-link-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone-link"></i>
                                                <div class="mt-8">icon-cellphone-link</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone-settings"></i>
                                                <div class="mt-8">icon-cellphone-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-cellphone"></i>
                                                <div class="mt-8">icon-cellphone</div>
                                            </div>

                                            <div>
                                                <i class="icon-certificate"></i>
                                                <div class="mt-8">icon-certificate</div>
                                            </div>

                                            <div>
                                                <i class="icon-chair-school"></i>
                                                <div class="mt-8">icon-chair-school</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-arc"></i>
                                                <div class="mt-8">icon-chart-arc</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-areaspline"></i>
                                                <div class="mt-8">icon-chart-areaspline</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-bar-stacked"></i>
                                                <div class="mt-8">icon-chart-bar-stacked</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-bar"></i>
                                                <div class="mt-8">icon-chart-bar</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-bubble"></i>
                                                <div class="mt-8">icon-chart-bubble</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-gantt"></i>
                                                <div class="mt-8">icon-chart-gantt</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-histogram"></i>
                                                <div class="mt-8">icon-chart-histogram</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-line-stacked"></i>
                                                <div class="mt-8">icon-chart-line-stacked</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-line"></i>
                                                <div class="mt-8">icon-chart-line</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-pie"></i>
                                                <div class="mt-8">icon-chart-pie</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-scatterplot-hexbin"></i>
                                                <div class="mt-8">icon-chart-scatterplot-hexbin</div>
                                            </div>

                                            <div>
                                                <i class="icon-chart-timeline"></i>
                                                <div class="mt-8">icon-chart-timeline</div>
                                            </div>

                                            <div>
                                                <i class="icon-check-all"></i>
                                                <div class="mt-8">icon-check-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-check-bookmark"></i>
                                                <div class="mt-8">icon-check-bookmark</div>
                                            </div>

                                            <div>
                                                <i class="icon-check-circle-outline"></i>
                                                <div class="mt-8">icon-check-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-check-circle"></i>
                                                <div class="mt-8">icon-check-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-check"></i>
                                                <div class="mt-8">icon-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-blank-circle-outline"></i>
                                                <div class="mt-8">icon-checkbox-blank-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-blank-circle"></i>
                                                <div class="mt-8">icon-checkbox-blank-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-blank-outline"></i>
                                                <div class="mt-8">icon-checkbox-blank-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-blank"></i>
                                                <div class="mt-8">icon-checkbox-blank</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-marked-circle-outline"></i>
                                                <div class="mt-8">icon-checkbox-marked-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-marked-circle"></i>
                                                <div class="mt-8">icon-checkbox-marked-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-marked-outline"></i>
                                                <div class="mt-8">icon-checkbox-marked-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-marked"></i>
                                                <div class="mt-8">icon-checkbox-marked</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-blank-circle-outline"></i>
                                                <div class="mt-8">icon-checkbox-multiple-blank-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-blank-circle"></i>
                                                <div class="mt-8">icon-checkbox-multiple-blank-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-blank-outline"></i>
                                                <div class="mt-8">icon-checkbox-multiple-blank-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-blank"></i>
                                                <div class="mt-8">icon-checkbox-multiple-blank</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-marked-circle-outline"></i>
                                                <div class="mt-8">icon-checkbox-multiple-marked-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-marked-circle"></i>
                                                <div class="mt-8">icon-checkbox-multiple-marked-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-marked-outline"></i>
                                                <div class="mt-8">icon-checkbox-multiple-marked-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkbox-multiple-marked"></i>
                                                <div class="mt-8">icon-checkbox-multiple-marked</div>
                                            </div>

                                            <div>
                                                <i class="icon-checkerboard"></i>
                                                <div class="mt-8">icon-checkerboard</div>
                                            </div>

                                            <div>
                                                <i class="icon-chemical-weapon"></i>
                                                <div class="mt-8">icon-chemical-weapon</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-double-down"></i>
                                                <div class="mt-8">icon-chevron-double-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-double-left"></i>
                                                <div class="mt-8">icon-chevron-double-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-double-right"></i>
                                                <div class="mt-8">icon-chevron-double-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-double-up"></i>
                                                <div class="mt-8">icon-chevron-double-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-down"></i>
                                                <div class="mt-8">icon-chevron-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-left"></i>
                                                <div class="mt-8">icon-chevron-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-right"></i>
                                                <div class="mt-8">icon-chevron-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-chevron-up"></i>
                                                <div class="mt-8">icon-chevron-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-chip"></i>
                                                <div class="mt-8">icon-chip</div>
                                            </div>

                                            <div>
                                                <i class="icon-church"></i>
                                                <div class="mt-8">icon-church</div>
                                            </div>

                                            <div>
                                                <i class="icon-circle-outline"></i>
                                                <div class="mt-8">icon-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-circle"></i>
                                                <div class="mt-8">icon-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-cisco-webex"></i>
                                                <div class="mt-8">icon-cisco-webex</div>
                                            </div>

                                            <div>
                                                <i class="icon-city"></i>
                                                <div class="mt-8">icon-city</div>
                                            </div>

                                            <div>
                                                <i class="icon-clapperboard"></i>
                                                <div class="mt-8">icon-clapperboard</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-account"></i>
                                                <div class="mt-8">icon-clipboard-account</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-alert"></i>
                                                <div class="mt-8">icon-clipboard-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-arrow-down"></i>
                                                <div class="mt-8">icon-clipboard-arrow-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-arrow-left"></i>
                                                <div class="mt-8">icon-clipboard-arrow-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-check"></i>
                                                <div class="mt-8">icon-clipboard-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-flow"></i>
                                                <div class="mt-8">icon-clipboard-flow</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-outline"></i>
                                                <div class="mt-8">icon-clipboard-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-plus"></i>
                                                <div class="mt-8">icon-clipboard-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard-text"></i>
                                                <div class="mt-8">icon-clipboard-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-clipboard"></i>
                                                <div class="mt-8">icon-clipboard</div>
                                            </div>

                                            <div>
                                                <i class="icon-clippy"></i>
                                                <div class="mt-8">icon-clippy</div>
                                            </div>

                                            <div>
                                                <i class="icon-clock-alert"></i>
                                                <div class="mt-8">icon-clock-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-clock-end"></i>
                                                <div class="mt-8">icon-clock-end</div>
                                            </div>

                                            <div>
                                                <i class="icon-clock-fast"></i>
                                                <div class="mt-8">icon-clock-fast</div>
                                            </div>

                                            <div>
                                                <i class="icon-clock-in"></i>
                                                <div class="mt-8">icon-clock-in</div>
                                            </div>

                                            <div>
                                                <i class="icon-clock-out"></i>
                                                <div class="mt-8">icon-clock-out</div>
                                            </div>

                                            <div>
                                                <i class="icon-clock-start"></i>
                                                <div class="mt-8">icon-clock-start</div>
                                            </div>

                                            <div>
                                                <i class="icon-clock"></i>
                                                <div class="mt-8">icon-clock</div>
                                            </div>

                                            <div>
                                                <i class="icon-close-circle-outline"></i>
                                                <div class="mt-8">icon-close-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-close-circle"></i>
                                                <div class="mt-8">icon-close-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-close-network"></i>
                                                <div class="mt-8">icon-close-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-close-octagon-outline"></i>
                                                <div class="mt-8">icon-close-octagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-close-octagon"></i>
                                                <div class="mt-8">icon-close-octagon</div>
                                            </div>

                                            <div>
                                                <i class="icon-close-outline"></i>
                                                <div class="mt-8">icon-close-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-close"></i>
                                                <div class="mt-8">icon-close</div>
                                            </div>

                                            <div>
                                                <i class="icon-closed-caption"></i>
                                                <div class="mt-8">icon-closed-caption</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-check"></i>
                                                <div class="mt-8">icon-cloud-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-circle"></i>
                                                <div class="mt-8">icon-cloud-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-download"></i>
                                                <div class="mt-8">icon-cloud-download</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-outline-off"></i>
                                                <div class="mt-8">icon-cloud-outline-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-outline"></i>
                                                <div class="mt-8">icon-cloud-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-print-outline"></i>
                                                <div class="mt-8">icon-cloud-print-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-print"></i>
                                                <div class="mt-8">icon-cloud-print</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-sync"></i>
                                                <div class="mt-8">icon-cloud-sync</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud-upload"></i>
                                                <div class="mt-8">icon-cloud-upload</div>
                                            </div>

                                            <div>
                                                <i class="icon-cloud"></i>
                                                <div class="mt-8">icon-cloud</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-array"></i>
                                                <div class="mt-8">icon-code-array</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-braces"></i>
                                                <div class="mt-8">icon-code-braces</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-brackets"></i>
                                                <div class="mt-8">icon-code-brackets</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-equal"></i>
                                                <div class="mt-8">icon-code-equal</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-greater-than-or-equal"></i>
                                                <div class="mt-8">icon-code-greater-than-or-equal</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-greater-than"></i>
                                                <div class="mt-8">icon-code-greater-than</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-less-than-or-equal"></i>
                                                <div class="mt-8">icon-code-less-than-or-equal</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-less-than"></i>
                                                <div class="mt-8">icon-code-less-than</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-not-equal-variant"></i>
                                                <div class="mt-8">icon-code-not-equal-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-not-equal"></i>
                                                <div class="mt-8">icon-code-not-equal</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-parentheses"></i>
                                                <div class="mt-8">icon-code-parentheses</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-string"></i>
                                                <div class="mt-8">icon-code-string</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-tags-check"></i>
                                                <div class="mt-8">icon-code-tags-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-code-tags"></i>
                                                <div class="mt-8">icon-code-tags</div>
                                            </div>

                                            <div>
                                                <i class="icon-codepen"></i>
                                                <div class="mt-8">icon-codepen</div>
                                            </div>

                                            <div>
                                                <i class="icon-coffee-outline"></i>
                                                <div class="mt-8">icon-coffee-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-coffee-to-go"></i>
                                                <div class="mt-8">icon-coffee-to-go</div>
                                            </div>

                                            <div>
                                                <i class="icon-coffee"></i>
                                                <div class="mt-8">icon-coffee</div>
                                            </div>

                                            <div>
                                                <i class="icon-coin"></i>
                                                <div class="mt-8">icon-coin</div>
                                            </div>

                                            <div>
                                                <i class="icon-coins"></i>
                                                <div class="mt-8">icon-coins</div>
                                            </div>

                                            <div>
                                                <i class="icon-collage"></i>
                                                <div class="mt-8">icon-collage</div>
                                            </div>

                                            <div>
                                                <i class="icon-color-helper"></i>
                                                <div class="mt-8">icon-color-helper</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-account-outline"></i>
                                                <div class="mt-8">icon-comment-account-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-account"></i>
                                                <div class="mt-8">icon-comment-account</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-alert-outline"></i>
                                                <div class="mt-8">icon-comment-alert-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-alert"></i>
                                                <div class="mt-8">icon-comment-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-check-outline"></i>
                                                <div class="mt-8">icon-comment-check-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-check"></i>
                                                <div class="mt-8">icon-comment-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-multipe-outline"></i>
                                                <div class="mt-8">icon-comment-multipe-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-outline"></i>
                                                <div class="mt-8">icon-comment-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-plus-outline"></i>
                                                <div class="mt-8">icon-comment-plus-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-processing-outline"></i>
                                                <div class="mt-8">icon-comment-processing-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-processing"></i>
                                                <div class="mt-8">icon-comment-processing</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-question-outline"></i>
                                                <div class="mt-8">icon-comment-question-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-remove-outline"></i>
                                                <div class="mt-8">icon-comment-remove-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-text-outline"></i>
                                                <div class="mt-8">icon-comment-text-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment-text"></i>
                                                <div class="mt-8">icon-comment-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-comment"></i>
                                                <div class="mt-8">icon-comment</div>
                                            </div>

                                            <div>
                                                <i class="icon-compare"></i>
                                                <div class="mt-8">icon-compare</div>
                                            </div>

                                            <div>
                                                <i class="icon-compass-outline"></i>
                                                <div class="mt-8">icon-compass-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-compass"></i>
                                                <div class="mt-8">icon-compass</div>
                                            </div>

                                            <div>
                                                <i class="icon-console"></i>
                                                <div class="mt-8">icon-console</div>
                                            </div>

                                            <div>
                                                <i class="icon-contact-mail"></i>
                                                <div class="mt-8">icon-contact-mail</div>
                                            </div>

                                            <div>
                                                <i class="icon-contacts"></i>
                                                <div class="mt-8">icon-contacts</div>
                                            </div>

                                            <div>
                                                <i class="icon-content-copy"></i>
                                                <div class="mt-8">icon-content-copy</div>
                                            </div>

                                            <div>
                                                <i class="icon-content-cut"></i>
                                                <div class="mt-8">icon-content-cut</div>
                                            </div>

                                            <div>
                                                <i class="icon-content-duplicate"></i>
                                                <div class="mt-8">icon-content-duplicate</div>
                                            </div>

                                            <div>
                                                <i class="icon-content-paste"></i>
                                                <div class="mt-8">icon-content-paste</div>
                                            </div>

                                            <div>
                                                <i class="icon-content-save-all"></i>
                                                <div class="mt-8">icon-content-save-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-content-save-settings"></i>
                                                <div class="mt-8">icon-content-save-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-content-save"></i>
                                                <div class="mt-8">icon-content-save</div>
                                            </div>

                                            <div>
                                                <i class="icon-contrast-box"></i>
                                                <div class="mt-8">icon-contrast-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-contrast-circle"></i>
                                                <div class="mt-8">icon-contrast-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-contrast"></i>
                                                <div class="mt-8">icon-contrast</div>
                                            </div>

                                            <div>
                                                <i class="icon-controller-xbox"></i>
                                                <div class="mt-8">icon-controller-xbox</div>
                                            </div>

                                            <div>
                                                <i class="icon-cookie"></i>
                                                <div class="mt-8">icon-cookie</div>
                                            </div>

                                            <div>
                                                <i class="icon-copyright"></i>
                                                <div class="mt-8">icon-copyright</div>
                                            </div>

                                            <div>
                                                <i class="icon-counter"></i>
                                                <div class="mt-8">icon-counter</div>
                                            </div>

                                            <div>
                                                <i class="icon-cow"></i>
                                                <div class="mt-8">icon-cow</div>
                                            </div>

                                            <div>
                                                <i class="icon-creation"></i>
                                                <div class="mt-8">icon-creation</div>
                                            </div>

                                            <div>
                                                <i class="icon-credit-card-multiple"></i>
                                                <div class="mt-8">icon-credit-card-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-credit-card-off"></i>
                                                <div class="mt-8">icon-credit-card-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-credit-card-plus"></i>
                                                <div class="mt-8">icon-credit-card-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-credit-card-scan"></i>
                                                <div class="mt-8">icon-credit-card-scan</div>
                                            </div>

                                            <div>
                                                <i class="icon-credit-card"></i>
                                                <div class="mt-8">icon-credit-card</div>
                                            </div>

                                            <div>
                                                <i class="icon-crop-free"></i>
                                                <div class="mt-8">icon-crop-free</div>
                                            </div>

                                            <div>
                                                <i class="icon-crop-landscape"></i>
                                                <div class="mt-8">icon-crop-landscape</div>
                                            </div>

                                            <div>
                                                <i class="icon-crop-portrait"></i>
                                                <div class="mt-8">icon-crop-portrait</div>
                                            </div>

                                            <div>
                                                <i class="icon-crop-rotate"></i>
                                                <div class="mt-8">icon-crop-rotate</div>
                                            </div>

                                            <div>
                                                <i class="icon-crop-square"></i>
                                                <div class="mt-8">icon-crop-square</div>
                                            </div>

                                            <div>
                                                <i class="icon-crop"></i>
                                                <div class="mt-8">icon-crop</div>
                                            </div>

                                            <div>
                                                <i class="icon-crosshairs-gps"></i>
                                                <div class="mt-8">icon-crosshairs-gps</div>
                                            </div>

                                            <div>
                                                <i class="icon-crosshairs"></i>
                                                <div class="mt-8">icon-crosshairs</div>
                                            </div>

                                            <div>
                                                <i class="icon-crown"></i>
                                                <div class="mt-8">icon-crown</div>
                                            </div>

                                            <div>
                                                <i class="icon-cube-outline"></i>
                                                <div class="mt-8">icon-cube-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-cube-send"></i>
                                                <div class="mt-8">icon-cube-send</div>
                                            </div>

                                            <div>
                                                <i class="icon-cube-unfolded"></i>
                                                <div class="mt-8">icon-cube-unfolded</div>
                                            </div>

                                            <div>
                                                <i class="icon-cube"></i>
                                                <div class="mt-8">icon-cube</div>
                                            </div>

                                            <div>
                                                <i class="icon-cup-off"></i>
                                                <div class="mt-8">icon-cup-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-cup-water"></i>
                                                <div class="mt-8">icon-cup-water</div>
                                            </div>

                                            <div>
                                                <i class="icon-cup"></i>
                                                <div class="mt-8">icon-cup</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-btc"></i>
                                                <div class="mt-8">icon-currency-btc</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-chf"></i>
                                                <div class="mt-8">icon-currency-chf</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-cny"></i>
                                                <div class="mt-8">icon-currency-cny</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-eur"></i>
                                                <div class="mt-8">icon-currency-eur</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-gbp"></i>
                                                <div class="mt-8">icon-currency-gbp</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-inr"></i>
                                                <div class="mt-8">icon-currency-inr</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-jpy"></i>
                                                <div class="mt-8">icon-currency-jpy</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-krw"></i>
                                                <div class="mt-8">icon-currency-krw</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-ngn"></i>
                                                <div class="mt-8">icon-currency-ngn</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-rub"></i>
                                                <div class="mt-8">icon-currency-rub</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-try"></i>
                                                <div class="mt-8">icon-currency-try</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-twd"></i>
                                                <div class="mt-8">icon-currency-twd</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-usd-off"></i>
                                                <div class="mt-8">icon-currency-usd-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-currency-usd"></i>
                                                <div class="mt-8">icon-currency-usd</div>
                                            </div>

                                            <div>
                                                <i class="icon-cursor-default-outline"></i>
                                                <div class="mt-8">icon-cursor-default-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-cursor-default"></i>
                                                <div class="mt-8">icon-cursor-default</div>
                                            </div>

                                            <div>
                                                <i class="icon-cursor-move"></i>
                                                <div class="mt-8">icon-cursor-move</div>
                                            </div>

                                            <div>
                                                <i class="icon-cursor-pointer"></i>
                                                <div class="mt-8">icon-cursor-pointer</div>
                                            </div>

                                            <div>
                                                <i class="icon-cursor-text"></i>
                                                <div class="mt-8">icon-cursor-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-data"></i>
                                                <div class="mt-8">icon-data</div>
                                            </div>

                                            <div>
                                                <i class="icon-database-minus"></i>
                                                <div class="mt-8">icon-database-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-database-plus"></i>
                                                <div class="mt-8">icon-database-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-database"></i>
                                                <div class="mt-8">icon-database</div>
                                            </div>

                                            <div>
                                                <i class="icon-debug-step-into"></i>
                                                <div class="mt-8">icon-debug-step-into</div>
                                            </div>

                                            <div>
                                                <i class="icon-debug-step-out"></i>
                                                <div class="mt-8">icon-debug-step-out</div>
                                            </div>

                                            <div>
                                                <i class="icon-debug-step-over"></i>
                                                <div class="mt-8">icon-debug-step-over</div>
                                            </div>

                                            <div>
                                                <i class="icon-decagram-outline"></i>
                                                <div class="mt-8">icon-decagram-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-decagram"></i>
                                                <div class="mt-8">icon-decagram</div>
                                            </div>

                                            <div>
                                                <i class="icon-decimal-decrease"></i>
                                                <div class="mt-8">icon-decimal-decrease</div>
                                            </div>

                                            <div>
                                                <i class="icon-decimal-increase"></i>
                                                <div class="mt-8">icon-decimal-increase</div>
                                            </div>

                                            <div>
                                                <i class="icon-delete-circle"></i>
                                                <div class="mt-8">icon-delete-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-delete-empty"></i>
                                                <div class="mt-8">icon-delete-empty</div>
                                            </div>

                                            <div>
                                                <i class="icon-delete-forever"></i>
                                                <div class="mt-8">icon-delete-forever</div>
                                            </div>

                                            <div>
                                                <i class="icon-delete-sweep"></i>
                                                <div class="mt-8">icon-delete-sweep</div>
                                            </div>

                                            <div>
                                                <i class="icon-delete-variant"></i>
                                                <div class="mt-8">icon-delete-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-delete"></i>
                                                <div class="mt-8">icon-delete</div>
                                            </div>

                                            <div>
                                                <i class="icon-delta"></i>
                                                <div class="mt-8">icon-delta</div>
                                            </div>

                                            <div>
                                                <i class="icon-deskphone"></i>
                                                <div class="mt-8">icon-deskphone</div>
                                            </div>

                                            <div>
                                                <i class="icon-desktop-mac"></i>
                                                <div class="mt-8">icon-desktop-mac</div>
                                            </div>

                                            <div>
                                                <i class="icon-desktop-tower"></i>
                                                <div class="mt-8">icon-desktop-tower</div>
                                            </div>

                                            <div>
                                                <i class="icon-details"></i>
                                                <div class="mt-8">icon-details</div>
                                            </div>

                                            <div>
                                                <i class="icon-developer-board"></i>
                                                <div class="mt-8">icon-developer-board</div>
                                            </div>

                                            <div>
                                                <i class="icon-deviantart"></i>
                                                <div class="mt-8">icon-deviantart</div>
                                            </div>

                                            <div>
                                                <i class="icon-dialpad"></i>
                                                <div class="mt-8">icon-dialpad</div>
                                            </div>

                                            <div>
                                                <i class="icon-diamond"></i>
                                                <div class="mt-8">icon-diamond</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-1"></i>
                                                <div class="mt-8">icon-dice-1</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-2"></i>
                                                <div class="mt-8">icon-dice-2</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-3"></i>
                                                <div class="mt-8">icon-dice-3</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-4"></i>
                                                <div class="mt-8">icon-dice-4</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-5"></i>
                                                <div class="mt-8">icon-dice-5</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-6"></i>
                                                <div class="mt-8">icon-dice-6</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-d4"></i>
                                                <div class="mt-8">icon-dice-d4</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-d6"></i>
                                                <div class="mt-8">icon-dice-d6</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-d8"></i>
                                                <div class="mt-8">icon-dice-d8</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-d10"></i>
                                                <div class="mt-8">icon-dice-d10</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-d20"></i>
                                                <div class="mt-8">icon-dice-d20</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice-multiple"></i>
                                                <div class="mt-8">icon-dice-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-dice"></i>
                                                <div class="mt-8">icon-dice</div>
                                            </div>

                                            <div>
                                                <i class="icon-dictionary"></i>
                                                <div class="mt-8">icon-dictionary</div>
                                            </div>

                                            <div>
                                                <i class="icon-directions-fork"></i>
                                                <div class="mt-8">icon-directions-fork</div>
                                            </div>

                                            <div>
                                                <i class="icon-directions"></i>
                                                <div class="mt-8">icon-directions</div>
                                            </div>

                                            <div>
                                                <i class="icon-discord"></i>
                                                <div class="mt-8">icon-discord</div>
                                            </div>

                                            <div>
                                                <i class="icon-disk-alert"></i>
                                                <div class="mt-8">icon-disk-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-disk"></i>
                                                <div class="mt-8">icon-disk</div>
                                            </div>

                                            <div>
                                                <i class="icon-disqus-outline"></i>
                                                <div class="mt-8">icon-disqus-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-disqus"></i>
                                                <div class="mt-8">icon-disqus</div>
                                            </div>

                                            <div>
                                                <i class="icon-division-box"></i>
                                                <div class="mt-8">icon-division-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-division"></i>
                                                <div class="mt-8">icon-division</div>
                                            </div>

                                            <div>
                                                <i class="icon-dna"></i>
                                                <div class="mt-8">icon-dna</div>
                                            </div>

                                            <div>
                                                <i class="icon-dns"></i>
                                                <div class="mt-8">icon-dns</div>
                                            </div>

                                            <div>
                                                <i class="icon-do-not-disturb-off"></i>
                                                <div class="mt-8">icon-do-not-disturb-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-do-not-disturb"></i>
                                                <div class="mt-8">icon-do-not-disturb</div>
                                            </div>

                                            <div>
                                                <i class="icon-document"></i>
                                                <div class="mt-8">icon-document</div>
                                            </div>

                                            <div>
                                                <i class="icon-dolby"></i>
                                                <div class="mt-8">icon-dolby</div>
                                            </div>

                                            <div>
                                                <i class="icon-domain"></i>
                                                <div class="mt-8">icon-domain</div>
                                            </div>

                                            <div>
                                                <i class="icon-dots-horizontal"></i>
                                                <div class="mt-8">icon-dots-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-dots-vertical"></i>
                                                <div class="mt-8">icon-dots-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-douban"></i>
                                                <div class="mt-8">icon-douban</div>
                                            </div>

                                            <div>
                                                <i class="icon-download"></i>
                                                <div class="mt-8">icon-download</div>
                                            </div>

                                            <div>
                                                <i class="icon-drag-horizontal"></i>
                                                <div class="mt-8">icon-drag-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-drag-vertical"></i>
                                                <div class="mt-8">icon-drag-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-drag"></i>
                                                <div class="mt-8">icon-drag</div>
                                            </div>

                                            <div>
                                                <i class="icon-drawing-box"></i>
                                                <div class="mt-8">icon-drawing-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-drawing"></i>
                                                <div class="mt-8">icon-drawing</div>
                                            </div>

                                            <div>
                                                <i class="icon-dribbble-box"></i>
                                                <div class="mt-8">icon-dribbble-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-dribbble"></i>
                                                <div class="mt-8">icon-dribbble</div>
                                            </div>

                                            <div>
                                                <i class="icon-drone"></i>
                                                <div class="mt-8">icon-drone</div>
                                            </div>

                                            <div>
                                                <i class="icon-dropbox"></i>
                                                <div class="mt-8">icon-dropbox</div>
                                            </div>

                                            <div>
                                                <i class="icon-drupal"></i>
                                                <div class="mt-8">icon-drupal</div>
                                            </div>

                                            <div>
                                                <i class="icon-duck"></i>
                                                <div class="mt-8">icon-duck</div>
                                            </div>

                                            <div>
                                                <i class="icon-dumbbell"></i>
                                                <div class="mt-8">icon-dumbbell</div>
                                            </div>

                                            <div>
                                                <i class="icon-earth-box-off"></i>
                                                <div class="mt-8">icon-earth-box-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-earth-box"></i>
                                                <div class="mt-8">icon-earth-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-earth-off"></i>
                                                <div class="mt-8">icon-earth-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-earth"></i>
                                                <div class="mt-8">icon-earth</div>
                                            </div>

                                            <div>
                                                <i class="icon-ebay"></i>
                                                <div class="mt-8">icon-ebay</div>
                                            </div>

                                            <div>
                                                <i class="icon-edge"></i>
                                                <div class="mt-8">icon-edge</div>
                                            </div>

                                            <div>
                                                <i class="icon-eject"></i>
                                                <div class="mt-8">icon-eject</div>
                                            </div>

                                            <div>
                                                <i class="icon-elevation-decline"></i>
                                                <div class="mt-8">icon-elevation-decline</div>
                                            </div>

                                            <div>
                                                <i class="icon-elevation-rise"></i>
                                                <div class="mt-8">icon-elevation-rise</div>
                                            </div>

                                            <div>
                                                <i class="icon-elevator"></i>
                                                <div class="mt-8">icon-elevator</div>
                                            </div>

                                            <div>
                                                <i class="icon-email-alert"></i>
                                                <div class="mt-8">icon-email-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-email-open-outline"></i>
                                                <div class="mt-8">icon-email-open-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-email-open"></i>
                                                <div class="mt-8">icon-email-open</div>
                                            </div>

                                            <div>
                                                <i class="icon-email-outline"></i>
                                                <div class="mt-8">icon-email-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-email-secure"></i>
                                                <div class="mt-8">icon-email-secure</div>
                                            </div>

                                            <div>
                                                <i class="icon-email-variant"></i>
                                                <div class="mt-8">icon-email-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-email"></i>
                                                <div class="mt-8">icon-email</div>
                                            </div>

                                            <div>
                                                <i class="icon-emby"></i>
                                                <div class="mt-8">icon-emby</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-cool"></i>
                                                <div class="mt-8">icon-emoticon-cool</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-dead"></i>
                                                <div class="mt-8">icon-emoticon-dead</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-devil"></i>
                                                <div class="mt-8">icon-emoticon-devil</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-excited"></i>
                                                <div class="mt-8">icon-emoticon-excited</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-happy"></i>
                                                <div class="mt-8">icon-emoticon-happy</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-neutral"></i>
                                                <div class="mt-8">icon-emoticon-neutral</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-poop"></i>
                                                <div class="mt-8">icon-emoticon-poop</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-sad"></i>
                                                <div class="mt-8">icon-emoticon-sad</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon-tongue"></i>
                                                <div class="mt-8">icon-emoticon-tongue</div>
                                            </div>

                                            <div>
                                                <i class="icon-emoticon"></i>
                                                <div class="mt-8">icon-emoticon</div>
                                            </div>

                                            <div>
                                                <i class="icon-engine-outline"></i>
                                                <div class="mt-8">icon-engine-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-engine"></i>
                                                <div class="mt-8">icon-engine</div>
                                            </div>

                                            <div>
                                                <i class="icon-equal-box"></i>
                                                <div class="mt-8">icon-equal-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-equal"></i>
                                                <div class="mt-8">icon-equal</div>
                                            </div>

                                            <div>
                                                <i class="icon-eraser-variant"></i>
                                                <div class="mt-8">icon-eraser-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-eraser"></i>
                                                <div class="mt-8">icon-eraser</div>
                                            </div>

                                            <div>
                                                <i class="icon-escalator"></i>
                                                <div class="mt-8">icon-escalator</div>
                                            </div>

                                            <div>
                                                <i class="icon-ethernet-cable-off"></i>
                                                <div class="mt-8">icon-ethernet-cable-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-ethernet-cable"></i>
                                                <div class="mt-8">icon-ethernet-cable</div>
                                            </div>

                                            <div>
                                                <i class="icon-ethernet"></i>
                                                <div class="mt-8">icon-ethernet</div>
                                            </div>

                                            <div>
                                                <i class="icon-etsy"></i>
                                                <div class="mt-8">icon-etsy</div>
                                            </div>

                                            <div>
                                                <i class="icon-ev-station"></i>
                                                <div class="mt-8">icon-ev-station</div>
                                            </div>

                                            <div>
                                                <i class="icon-evernote"></i>
                                                <div class="mt-8">icon-evernote</div>
                                            </div>

                                            <div>
                                                <i class="icon-exclamation"></i>
                                                <div class="mt-8">icon-exclamation</div>
                                            </div>

                                            <div>
                                                <i class="icon-exit-to-app"></i>
                                                <div class="mt-8">icon-exit-to-app</div>
                                            </div>

                                            <div>
                                                <i class="icon-export"></i>
                                                <div class="mt-8">icon-export</div>
                                            </div>

                                            <div>
                                                <i class="icon-eye-off"></i>
                                                <div class="mt-8">icon-eye-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-eye-outline-off"></i>
                                                <div class="mt-8">icon-eye-outline-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-eye-outline"></i>
                                                <div class="mt-8">icon-eye-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-eye"></i>
                                                <div class="mt-8">icon-eye</div>
                                            </div>

                                            <div>
                                                <i class="icon-eyedropper-variant"></i>
                                                <div class="mt-8">icon-eyedropper-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-eyedropper"></i>
                                                <div class="mt-8">icon-eyedropper</div>
                                            </div>

                                            <div>
                                                <i class="icon-face-profile"></i>
                                                <div class="mt-8">icon-face-profile</div>
                                            </div>

                                            <div>
                                                <i class="icon-face"></i>
                                                <div class="mt-8">icon-face</div>
                                            </div>

                                            <div>
                                                <i class="icon-facebook-box"></i>
                                                <div class="mt-8">icon-facebook-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-facebook-messenger"></i>
                                                <div class="mt-8">icon-facebook-messenger</div>
                                            </div>

                                            <div>
                                                <i class="icon-facebook"></i>
                                                <div class="mt-8">icon-facebook</div>
                                            </div>

                                            <div>
                                                <i class="icon-factory"></i>
                                                <div class="mt-8">icon-factory</div>
                                            </div>

                                            <div>
                                                <i class="icon-fan"></i>
                                                <div class="mt-8">icon-fan</div>
                                            </div>

                                            <div>
                                                <i class="icon-fast-forward-outline"></i>
                                                <div class="mt-8">icon-fast-forward-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-fast-forward"></i>
                                                <div class="mt-8">icon-fast-forward</div>
                                            </div>

                                            <div>
                                                <i class="icon-fax"></i>
                                                <div class="mt-8">icon-fax</div>
                                            </div>

                                            <div>
                                                <i class="icon-feather"></i>
                                                <div class="mt-8">icon-feather</div>
                                            </div>

                                            <div>
                                                <i class="icon-ferry"></i>
                                                <div class="mt-8">icon-ferry</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-account"></i>
                                                <div class="mt-8">icon-file-account</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-chart"></i>
                                                <div class="mt-8">icon-file-chart</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-check"></i>
                                                <div class="mt-8">icon-file-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-cloud"></i>
                                                <div class="mt-8">icon-file-cloud</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-delimited"></i>
                                                <div class="mt-8">icon-file-delimited</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-document-box"></i>
                                                <div class="mt-8">icon-file-document-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-document"></i>
                                                <div class="mt-8">icon-file-document</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-excel-box"></i>
                                                <div class="mt-8">icon-file-excel-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-excel"></i>
                                                <div class="mt-8">icon-file-excel</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-export"></i>
                                                <div class="mt-8">icon-file-export</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-find"></i>
                                                <div class="mt-8">icon-file-find</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-hidden"></i>
                                                <div class="mt-8">icon-file-hidden</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-image-box"></i>
                                                <div class="mt-8">icon-file-image-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-image"></i>
                                                <div class="mt-8">icon-file-image</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-import"></i>
                                                <div class="mt-8">icon-file-import</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-lock"></i>
                                                <div class="mt-8">icon-file-lock</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-move"></i>
                                                <div class="mt-8">icon-file-move</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-multiple"></i>
                                                <div class="mt-8">icon-file-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-music"></i>
                                                <div class="mt-8">icon-file-music</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-outline"></i>
                                                <div class="mt-8">icon-file-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-pdf-box"></i>
                                                <div class="mt-8">icon-file-pdf-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-pdf"></i>
                                                <div class="mt-8">icon-file-pdf</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-plus"></i>
                                                <div class="mt-8">icon-file-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-powerpoint-box"></i>
                                                <div class="mt-8">icon-file-powerpoint-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-powerpoint"></i>
                                                <div class="mt-8">icon-file-powerpoint</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-presentation-box"></i>
                                                <div class="mt-8">icon-file-presentation-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-restore"></i>
                                                <div class="mt-8">icon-file-restore</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-send"></i>
                                                <div class="mt-8">icon-file-send</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-tree"></i>
                                                <div class="mt-8">icon-file-tree</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-video"></i>
                                                <div class="mt-8">icon-file-video</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-word-box"></i>
                                                <div class="mt-8">icon-file-word-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-word"></i>
                                                <div class="mt-8">icon-file-word</div>
                                            </div>

                                            <div>
                                                <i class="icon-file-xml"></i>
                                                <div class="mt-8">icon-file-xml</div>
                                            </div>

                                            <div>
                                                <i class="icon-file"></i>
                                                <div class="mt-8">icon-file</div>
                                            </div>

                                            <div>
                                                <i class="icon-fill"></i>
                                                <div class="mt-8">icon-fill</div>
                                            </div>

                                            <div>
                                                <i class="icon-film"></i>
                                                <div class="mt-8">icon-film</div>
                                            </div>

                                            <div>
                                                <i class="icon-filmstrip-off"></i>
                                                <div class="mt-8">icon-filmstrip-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-filmstrip"></i>
                                                <div class="mt-8">icon-filmstrip</div>
                                            </div>

                                            <div>
                                                <i class="icon-filter-outline"></i>
                                                <div class="mt-8">icon-filter-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-filter-remove-outline"></i>
                                                <div class="mt-8">icon-filter-remove-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-filter-remove"></i>
                                                <div class="mt-8">icon-filter-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-filter-variant"></i>
                                                <div class="mt-8">icon-filter-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-filter"></i>
                                                <div class="mt-8">icon-filter</div>
                                            </div>

                                            <div>
                                                <i class="icon-find-replace"></i>
                                                <div class="mt-8">icon-find-replace</div>
                                            </div>

                                            <div>
                                                <i class="icon-fingerprint"></i>
                                                <div class="mt-8">icon-fingerprint</div>
                                            </div>

                                            <div>
                                                <i class="icon-fire"></i>
                                                <div class="mt-8">icon-fire</div>
                                            </div>

                                            <div>
                                                <i class="icon-fish"></i>
                                                <div class="mt-8">icon-fish</div>
                                            </div>

                                            <div>
                                                <i class="icon-flag-checkered-variant"></i>
                                                <div class="mt-8">icon-flag-checkered-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-flag-checkered"></i>
                                                <div class="mt-8">icon-flag-checkered</div>
                                            </div>

                                            <div>
                                                <i class="icon-flag-outline-variant"></i>
                                                <div class="mt-8">icon-flag-outline-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-flag-outline"></i>
                                                <div class="mt-8">icon-flag-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-flag-triangle"></i>
                                                <div class="mt-8">icon-flag-triangle</div>
                                            </div>

                                            <div>
                                                <i class="icon-flag-variant"></i>
                                                <div class="mt-8">icon-flag-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-flag"></i>
                                                <div class="mt-8">icon-flag</div>
                                            </div>

                                            <div>
                                                <i class="icon-flash-auto"></i>
                                                <div class="mt-8">icon-flash-auto</div>
                                            </div>

                                            <div>
                                                <i class="icon-flash-off"></i>
                                                <div class="mt-8">icon-flash-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-flash-outline"></i>
                                                <div class="mt-8">icon-flash-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-flash-red-eye"></i>
                                                <div class="mt-8">icon-flash-red-eye</div>
                                            </div>

                                            <div>
                                                <i class="icon-flash"></i>
                                                <div class="mt-8">icon-flash</div>
                                            </div>

                                            <div>
                                                <i class="icon-flashlight-off"></i>
                                                <div class="mt-8">icon-flashlight-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-flashlight"></i>
                                                <div class="mt-8">icon-flashlight</div>
                                            </div>

                                            <div>
                                                <i class="icon-flask-empty-outline"></i>
                                                <div class="mt-8">icon-flask-empty-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-flask-empty"></i>
                                                <div class="mt-8">icon-flask-empty</div>
                                            </div>

                                            <div>
                                                <i class="icon-flask-outline"></i>
                                                <div class="mt-8">icon-flask-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-flask"></i>
                                                <div class="mt-8">icon-flask</div>
                                            </div>

                                            <div>
                                                <i class="icon-flattr"></i>
                                                <div class="mt-8">icon-flattr</div>
                                            </div>

                                            <div>
                                                <i class="icon-flickr-after"></i>
                                                <div class="mt-8">icon-flickr-after</div>
                                            </div>

                                            <div>
                                                <i class="icon-flickr-before"></i>
                                                <div class="mt-8">icon-flickr-before</div>
                                            </div>

                                            <div>
                                                <i class="icon-flip-to-back"></i>
                                                <div class="mt-8">icon-flip-to-back</div>
                                            </div>

                                            <div>
                                                <i class="icon-flip-to-front"></i>
                                                <div class="mt-8">icon-flip-to-front</div>
                                            </div>

                                            <div>
                                                <i class="icon-floppy"></i>
                                                <div class="mt-8">icon-floppy</div>
                                            </div>

                                            <div>
                                                <i class="icon-flower"></i>
                                                <div class="mt-8">icon-flower</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-account"></i>
                                                <div class="mt-8">icon-folder-account</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-download"></i>
                                                <div class="mt-8">icon-folder-download</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-google-drive"></i>
                                                <div class="mt-8">icon-folder-google-drive</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-image"></i>
                                                <div class="mt-8">icon-folder-image</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-lock-open"></i>
                                                <div class="mt-8">icon-folder-lock-open</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-lock"></i>
                                                <div class="mt-8">icon-folder-lock</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-move"></i>
                                                <div class="mt-8">icon-folder-move</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-multiple-image"></i>
                                                <div class="mt-8">icon-folder-multiple-image</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-multiple-outline"></i>
                                                <div class="mt-8">icon-folder-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-multiple"></i>
                                                <div class="mt-8">icon-folder-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-open"></i>
                                                <div class="mt-8">icon-folder-open</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-outline-lock"></i>
                                                <div class="mt-8">icon-folder-outline-lock</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-outline"></i>
                                                <div class="mt-8">icon-folder-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-plus"></i>
                                                <div class="mt-8">icon-folder-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-remove"></i>
                                                <div class="mt-8">icon-folder-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-star"></i>
                                                <div class="mt-8">icon-folder-star</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder-upload"></i>
                                                <div class="mt-8">icon-folder-upload</div>
                                            </div>

                                            <div>
                                                <i class="icon-folder"></i>
                                                <div class="mt-8">icon-folder</div>
                                            </div>

                                            <div>
                                                <i class="icon-font-awesome"></i>
                                                <div class="mt-8">icon-font-awesome</div>
                                            </div>

                                            <div>
                                                <i class="icon-food-apple"></i>
                                                <div class="mt-8">icon-food-apple</div>
                                            </div>

                                            <div>
                                                <i class="icon-food-fork-drink"></i>
                                                <div class="mt-8">icon-food-fork-drink</div>
                                            </div>

                                            <div>
                                                <i class="icon-food-off"></i>
                                                <div class="mt-8">icon-food-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-food-variant"></i>
                                                <div class="mt-8">icon-food-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-food"></i>
                                                <div class="mt-8">icon-food</div>
                                            </div>

                                            <div>
                                                <i class="icon-football-australian"></i>
                                                <div class="mt-8">icon-football-australian</div>
                                            </div>

                                            <div>
                                                <i class="icon-football-helmet"></i>
                                                <div class="mt-8">icon-football-helmet</div>
                                            </div>

                                            <div>
                                                <i class="icon-football"></i>
                                                <div class="mt-8">icon-football</div>
                                            </div>

                                            <div>
                                                <i class="icon-footer"></i>
                                                <div class="mt-8">icon-footer</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-align-bottom"></i>
                                                <div class="mt-8">icon-format-align-bottom</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-align-center"></i>
                                                <div class="mt-8">icon-format-align-center</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-align-justify"></i>
                                                <div class="mt-8">icon-format-align-justify</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-align-left"></i>
                                                <div class="mt-8">icon-format-align-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-align-middle"></i>
                                                <div class="mt-8">icon-format-align-middle</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-align-right"></i>
                                                <div class="mt-8">icon-format-align-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-align-top"></i>
                                                <div class="mt-8">icon-format-align-top</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-annotation-plus"></i>
                                                <div class="mt-8">icon-format-annotation-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-bold"></i>
                                                <div class="mt-8">icon-format-bold</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-clear"></i>
                                                <div class="mt-8">icon-format-clear</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-color-fill"></i>
                                                <div class="mt-8">icon-format-color-fill</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-color-text"></i>
                                                <div class="mt-8">icon-format-color-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-color"></i>
                                                <div class="mt-8">icon-format-color</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-float-center"></i>
                                                <div class="mt-8">icon-format-float-center</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-float-left"></i>
                                                <div class="mt-8">icon-format-float-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-float-none"></i>
                                                <div class="mt-8">icon-format-float-none</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-float-right"></i>
                                                <div class="mt-8">icon-format-float-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-font"></i>
                                                <div class="mt-8">icon-format-font</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-1"></i>
                                                <div class="mt-8">icon-format-header-1</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-2"></i>
                                                <div class="mt-8">icon-format-header-2</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-3"></i>
                                                <div class="mt-8">icon-format-header-3</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-4"></i>
                                                <div class="mt-8">icon-format-header-4</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-5"></i>
                                                <div class="mt-8">icon-format-header-5</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-6"></i>
                                                <div class="mt-8">icon-format-header-6</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-decrease"></i>
                                                <div class="mt-8">icon-format-header-decrease</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-down"></i>
                                                <div class="mt-8">icon-format-header-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-equal"></i>
                                                <div class="mt-8">icon-format-header-equal</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-increase"></i>
                                                <div class="mt-8">icon-format-header-increase</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-pound"></i>
                                                <div class="mt-8">icon-format-header-pound</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-header-up"></i>
                                                <div class="mt-8">icon-format-header-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-horizontal-align-center"></i>
                                                <div class="mt-8">icon-format-horizontal-align-center</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-horizontal-align-left"></i>
                                                <div class="mt-8">icon-format-horizontal-align-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-horizontal-align-right"></i>
                                                <div class="mt-8">icon-format-horizontal-align-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-indent-decrease"></i>
                                                <div class="mt-8">icon-format-indent-decrease</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-indent-increase"></i>
                                                <div class="mt-8">icon-format-indent-increase</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-italic"></i>
                                                <div class="mt-8">icon-format-italic</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-line-spacing"></i>
                                                <div class="mt-8">icon-format-line-spacing</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-line-style"></i>
                                                <div class="mt-8">icon-format-line-style</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-line-weight"></i>
                                                <div class="mt-8">icon-format-line-weight</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-list-bulleted-type"></i>
                                                <div class="mt-8">icon-format-list-bulleted-type</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-list-bulleted"></i>
                                                <div class="mt-8">icon-format-list-bulleted</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-list-checks"></i>
                                                <div class="mt-8">icon-format-list-checks</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-list-numbers"></i>
                                                <div class="mt-8">icon-format-list-numbers</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-object-inline"></i>
                                                <div class="mt-8">icon-format-object-inline</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-object-square"></i>
                                                <div class="mt-8">icon-format-object-square</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-object-tight"></i>
                                                <div class="mt-8">icon-format-object-tight</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-object-top-bottom"></i>
                                                <div class="mt-8">icon-format-object-top-bottom</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-page-break"></i>
                                                <div class="mt-8">icon-format-page-break</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-paint"></i>
                                                <div class="mt-8">icon-format-paint</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-paragraph"></i>
                                                <div class="mt-8">icon-format-paragraph</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-pilcrow"></i>
                                                <div class="mt-8">icon-format-pilcrow</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-quote-close"></i>
                                                <div class="mt-8">icon-format-quote-close</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-quote-open"></i>
                                                <div class="mt-8">icon-format-quote-open</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-section"></i>
                                                <div class="mt-8">icon-format-section</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-size"></i>
                                                <div class="mt-8">icon-format-size</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-strikethrough-variant"></i>
                                                <div class="mt-8">icon-format-strikethrough-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-strikethrough"></i>
                                                <div class="mt-8">icon-format-strikethrough</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-subscript"></i>
                                                <div class="mt-8">icon-format-subscript</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-superscript"></i>
                                                <div class="mt-8">icon-format-superscript</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-text"></i>
                                                <div class="mt-8">icon-format-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-textdirection-l-to-r"></i>
                                                <div class="mt-8">icon-format-textdirection-l-to-r</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-textdirection-r-to-l"></i>
                                                <div class="mt-8">icon-format-textdirection-r-to-l</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-title"></i>
                                                <div class="mt-8">icon-format-title</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-underline"></i>
                                                <div class="mt-8">icon-format-underline</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-vertical-align-bottom"></i>
                                                <div class="mt-8">icon-format-vertical-align-bottom</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-vertical-align-center"></i>
                                                <div class="mt-8">icon-format-vertical-align-center</div>
                                            </div>

                                            <div>
                                                <i class="icon-format-vertical-align-top"></i>
                                                <div class="mt-8">icon-format-vertical-align-top</div>
                                            </div>

                                            <div>
                                                <i class="icon-forum"></i>
                                                <div class="mt-8">icon-forum</div>
                                            </div>

                                            <div>
                                                <i class="icon-forward"></i>
                                                <div class="mt-8">icon-forward</div>
                                            </div>

                                            <div>
                                                <i class="icon-foursquare"></i>
                                                <div class="mt-8">icon-foursquare</div>
                                            </div>

                                            <div>
                                                <i class="icon-fridge-filled-bottom"></i>
                                                <div class="mt-8">icon-fridge-filled-bottom</div>
                                            </div>

                                            <div>
                                                <i class="icon-fridge-filled-top"></i>
                                                <div class="mt-8">icon-fridge-filled-top</div>
                                            </div>

                                            <div>
                                                <i class="icon-fridge-filled"></i>
                                                <div class="mt-8">icon-fridge-filled</div>
                                            </div>

                                            <div>
                                                <i class="icon-fridge"></i>
                                                <div class="mt-8">icon-fridge</div>
                                            </div>

                                            <div>
                                                <i class="icon-fullscreen-exit"></i>
                                                <div class="mt-8">icon-fullscreen-exit</div>
                                            </div>

                                            <div>
                                                <i class="icon-fullscreen"></i>
                                                <div class="mt-8">icon-fullscreen</div>
                                            </div>

                                            <div>
                                                <i class="icon-function"></i>
                                                <div class="mt-8">icon-function</div>
                                            </div>

                                            <div>
                                                <i class="icon-gamepad-variant"></i>
                                                <div class="mt-8">icon-gamepad-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-gamepad"></i>
                                                <div class="mt-8">icon-gamepad</div>
                                            </div>

                                            <div>
                                                <i class="icon-garage-open"></i>
                                                <div class="mt-8">icon-garage-open</div>
                                            </div>

                                            <div>
                                                <i class="icon-garage"></i>
                                                <div class="mt-8">icon-garage</div>
                                            </div>

                                            <div>
                                                <i class="icon-gas-cylinder"></i>
                                                <div class="mt-8">icon-gas-cylinder</div>
                                            </div>

                                            <div>
                                                <i class="icon-gas-station"></i>
                                                <div class="mt-8">icon-gas-station</div>
                                            </div>

                                            <div>
                                                <i class="icon-gate"></i>
                                                <div class="mt-8">icon-gate</div>
                                            </div>

                                            <div>
                                                <i class="icon-gauge"></i>
                                                <div class="mt-8">icon-gauge</div>
                                            </div>

                                            <div>
                                                <i class="icon-gavel"></i>
                                                <div class="mt-8">icon-gavel</div>
                                            </div>

                                            <div>
                                                <i class="icon-gender-female"></i>
                                                <div class="mt-8">icon-gender-female</div>
                                            </div>

                                            <div>
                                                <i class="icon-gender-male-female"></i>
                                                <div class="mt-8">icon-gender-male-female</div>
                                            </div>

                                            <div>
                                                <i class="icon-gender-male"></i>
                                                <div class="mt-8">icon-gender-male</div>
                                            </div>

                                            <div>
                                                <i class="icon-gender-transgender"></i>
                                                <div class="mt-8">icon-gender-transgender</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-double-tap"></i>
                                                <div class="mt-8">icon-gesture-double-tap</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-swipe-down"></i>
                                                <div class="mt-8">icon-gesture-swipe-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-swipe-left"></i>
                                                <div class="mt-8">icon-gesture-swipe-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-swipe-right"></i>
                                                <div class="mt-8">icon-gesture-swipe-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-swipe-up"></i>
                                                <div class="mt-8">icon-gesture-swipe-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-tap"></i>
                                                <div class="mt-8">icon-gesture-tap</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-two-double-tap"></i>
                                                <div class="mt-8">icon-gesture-two-double-tap</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture-two-tap"></i>
                                                <div class="mt-8">icon-gesture-two-tap</div>
                                            </div>

                                            <div>
                                                <i class="icon-gesture"></i>
                                                <div class="mt-8">icon-gesture</div>
                                            </div>

                                            <div>
                                                <i class="icon-ghost"></i>
                                                <div class="mt-8">icon-ghost</div>
                                            </div>

                                            <div>
                                                <i class="icon-gift"></i>
                                                <div class="mt-8">icon-gift</div>
                                            </div>

                                            <div>
                                                <i class="icon-git"></i>
                                                <div class="mt-8">icon-git</div>
                                            </div>

                                            <div>
                                                <i class="icon-github-box"></i>
                                                <div class="mt-8">icon-github-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-github-face"></i>
                                                <div class="mt-8">icon-github-face</div>
                                            </div>

                                            <div>
                                                <i class="icon-github"></i>
                                                <div class="mt-8">icon-github</div>
                                            </div>

                                            <div>
                                                <i class="icon-glass-flute"></i>
                                                <div class="mt-8">icon-glass-flute</div>
                                            </div>

                                            <div>
                                                <i class="icon-glass-mug"></i>
                                                <div class="mt-8">icon-glass-mug</div>
                                            </div>

                                            <div>
                                                <i class="icon-glass-stange"></i>
                                                <div class="mt-8">icon-glass-stange</div>
                                            </div>

                                            <div>
                                                <i class="icon-glass-tulip"></i>
                                                <div class="mt-8">icon-glass-tulip</div>
                                            </div>

                                            <div>
                                                <i class="icon-glassdoor"></i>
                                                <div class="mt-8">icon-glassdoor</div>
                                            </div>

                                            <div>
                                                <i class="icon-glasses"></i>
                                                <div class="mt-8">icon-glasses</div>
                                            </div>

                                            <div>
                                                <i class="icon-gmail"></i>
                                                <div class="mt-8">icon-gmail</div>
                                            </div>

                                            <div>
                                                <i class="icon-gnome"></i>
                                                <div class="mt-8">icon-gnome</div>
                                            </div>

                                            <div>
                                                <i class="icon-gondola"></i>
                                                <div class="mt-8">icon-gondola</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-cardboard"></i>
                                                <div class="mt-8">icon-google-cardboard</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-chrome"></i>
                                                <div class="mt-8">icon-google-chrome</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-circles-communities"></i>
                                                <div class="mt-8">icon-google-circles-communities</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-circles-extended"></i>
                                                <div class="mt-8">icon-google-circles-extended</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-circles-invite"></i>
                                                <div class="mt-8">icon-google-circles-invite</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-circles"></i>
                                                <div class="mt-8">icon-google-circles</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-controller-off"></i>
                                                <div class="mt-8">icon-google-controller-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-controller"></i>
                                                <div class="mt-8">icon-google-controller</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-drive"></i>
                                                <div class="mt-8">icon-google-drive</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-earth"></i>
                                                <div class="mt-8">icon-google-earth</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-glass"></i>
                                                <div class="mt-8">icon-google-glass</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-keep"></i>
                                                <div class="mt-8">icon-google-keep</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-maps"></i>
                                                <div class="mt-8">icon-google-maps</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-nearby"></i>
                                                <div class="mt-8">icon-google-nearby</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-pages"></i>
                                                <div class="mt-8">icon-google-pages</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-photos"></i>
                                                <div class="mt-8">icon-google-photos</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-physical-web"></i>
                                                <div class="mt-8">icon-google-physical-web</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-play"></i>
                                                <div class="mt-8">icon-google-play</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-plus-box"></i>
                                                <div class="mt-8">icon-google-plus-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-plus"></i>
                                                <div class="mt-8">icon-google-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-translate"></i>
                                                <div class="mt-8">icon-google-translate</div>
                                            </div>

                                            <div>
                                                <i class="icon-google-wallet"></i>
                                                <div class="mt-8">icon-google-wallet</div>
                                            </div>

                                            <div>
                                                <i class="icon-google"></i>
                                                <div class="mt-8">icon-google</div>
                                            </div>

                                            <div>
                                                <i class="icon-gradient"></i>
                                                <div class="mt-8">icon-gradient</div>
                                            </div>

                                            <div>
                                                <i class="icon-grease-pencil"></i>
                                                <div class="mt-8">icon-grease-pencil</div>
                                            </div>

                                            <div>
                                                <i class="icon-grid-large"></i>
                                                <div class="mt-8">icon-grid-large</div>
                                            </div>

                                            <div>
                                                <i class="icon-grid-off"></i>
                                                <div class="mt-8">icon-grid-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-grid"></i>
                                                <div class="mt-8">icon-grid</div>
                                            </div>

                                            <div>
                                                <i class="icon-group"></i>
                                                <div class="mt-8">icon-group</div>
                                            </div>

                                            <div>
                                                <i class="icon-guitar-acoustic"></i>
                                                <div class="mt-8">icon-guitar-acoustic</div>
                                            </div>

                                            <div>
                                                <i class="icon-guitar-electric"></i>
                                                <div class="mt-8">icon-guitar-electric</div>
                                            </div>

                                            <div>
                                                <i class="icon-hackernews"></i>
                                                <div class="mt-8">icon-hackernews</div>
                                            </div>

                                            <div>
                                                <i class="icon-hamburger"></i>
                                                <div class="mt-8">icon-hamburger</div>
                                            </div>

                                            <div>
                                                <i class="icon-hand-pointing-right"></i>
                                                <div class="mt-8">icon-hand-pointing-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-hanger"></i>
                                                <div class="mt-8">icon-hanger</div>
                                            </div>

                                            <div>
                                                <i class="icon-hangouts"></i>
                                                <div class="mt-8">icon-hangouts</div>
                                            </div>

                                            <div>
                                                <i class="icon-harddisk"></i>
                                                <div class="mt-8">icon-harddisk</div>
                                            </div>

                                            <div>
                                                <i class="icon-headphones-box"></i>
                                                <div class="mt-8">icon-headphones-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-headphones-settings"></i>
                                                <div class="mt-8">icon-headphones-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-headphones"></i>
                                                <div class="mt-8">icon-headphones</div>
                                            </div>

                                            <div>
                                                <i class="icon-headset-dock"></i>
                                                <div class="mt-8">icon-headset-dock</div>
                                            </div>

                                            <div>
                                                <i class="icon-headset-off"></i>
                                                <div class="mt-8">icon-headset-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-headset"></i>
                                                <div class="mt-8">icon-headset</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-box-outline"></i>
                                                <div class="mt-8">icon-heart-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-box"></i>
                                                <div class="mt-8">icon-heart-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-broken"></i>
                                                <div class="mt-8">icon-heart-broken</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-half-full-outline"></i>
                                                <div class="mt-8">icon-heart-half-full-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-half-outline"></i>
                                                <div class="mt-8">icon-heart-half-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-half"></i>
                                                <div class="mt-8">icon-heart-half</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-off"></i>
                                                <div class="mt-8">icon-heart-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-outline"></i>
                                                <div class="mt-8">icon-heart-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart-pulse"></i>
                                                <div class="mt-8">icon-heart-pulse</div>
                                            </div>

                                            <div>
                                                <i class="icon-heart"></i>
                                                <div class="mt-8">icon-heart</div>
                                            </div>

                                            <div>
                                                <i class="icon-help-box"></i>
                                                <div class="mt-8">icon-help-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-help-circle-outline"></i>
                                                <div class="mt-8">icon-help-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-help-circle"></i>
                                                <div class="mt-8">icon-help-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-help"></i>
                                                <div class="mt-8">icon-help</div>
                                            </div>

                                            <div>
                                                <i class="icon-hexagon-multiple"></i>
                                                <div class="mt-8">icon-hexagon-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-hexagon-outline"></i>
                                                <div class="mt-8">icon-hexagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-hexagon"></i>
                                                <div class="mt-8">icon-hexagon</div>
                                            </div>

                                            <div>
                                                <i class="icon-highway"></i>
                                                <div class="mt-8">icon-highway</div>
                                            </div>

                                            <div>
                                                <i class="icon-history"></i>
                                                <div class="mt-8">icon-history</div>
                                            </div>

                                            <div>
                                                <i class="icon-hololens"></i>
                                                <div class="mt-8">icon-hololens</div>
                                            </div>

                                            <div>
                                                <i class="icon-home-map-marker"></i>
                                                <div class="mt-8">icon-home-map-marker</div>
                                            </div>

                                            <div>
                                                <i class="icon-home-modern"></i>
                                                <div class="mt-8">icon-home-modern</div>
                                            </div>

                                            <div>
                                                <i class="icon-home-outline"></i>
                                                <div class="mt-8">icon-home-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-home-variant"></i>
                                                <div class="mt-8">icon-home-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-home"></i>
                                                <div class="mt-8">icon-home</div>
                                            </div>

                                            <div>
                                                <i class="icon-hook-off"></i>
                                                <div class="mt-8">icon-hook-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-hook"></i>
                                                <div class="mt-8">icon-hook</div>
                                            </div>

                                            <div>
                                                <i class="icon-hops"></i>
                                                <div class="mt-8">icon-hops</div>
                                            </div>

                                            <div>
                                                <i class="icon-hospital-building"></i>
                                                <div class="mt-8">icon-hospital-building</div>
                                            </div>

                                            <div>
                                                <i class="icon-hospital-marker"></i>
                                                <div class="mt-8">icon-hospital-marker</div>
                                            </div>

                                            <div>
                                                <i class="icon-hospital"></i>
                                                <div class="mt-8">icon-hospital</div>
                                            </div>

                                            <div>
                                                <i class="icon-hotel"></i>
                                                <div class="mt-8">icon-hotel</div>
                                            </div>

                                            <div>
                                                <i class="icon-houzz-box"></i>
                                                <div class="mt-8">icon-houzz-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-child"></i>
                                                <div class="mt-8">icon-human-child</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-female"></i>
                                                <div class="mt-8">icon-human-female</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-greeting"></i>
                                                <div class="mt-8">icon-human-greeting</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-handsdown"></i>
                                                <div class="mt-8">icon-human-handsdown</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-handsup"></i>
                                                <div class="mt-8">icon-human-handsup</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-male-female"></i>
                                                <div class="mt-8">icon-human-male-female</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-male"></i>
                                                <div class="mt-8">icon-human-male</div>
                                            </div>

                                            <div>
                                                <i class="icon-human-pregnant"></i>
                                                <div class="mt-8">icon-human-pregnant</div>
                                            </div>

                                            <div>
                                                <i class="icon-human"></i>
                                                <div class="mt-8">icon-human</div>
                                            </div>

                                            <div>
                                                <i class="icon-humble-bundle"></i>
                                                <div class="mt-8">icon-humble-bundle</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-album"></i>
                                                <div class="mt-8">icon-image-album</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-area-close"></i>
                                                <div class="mt-8">icon-image-area-close</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-area"></i>
                                                <div class="mt-8">icon-image-area</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-broken-variant"></i>
                                                <div class="mt-8">icon-image-broken-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-broken"></i>
                                                <div class="mt-8">icon-image-broken</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-black-white"></i>
                                                <div class="mt-8">icon-image-filter-black-white</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-center-focus-weak"></i>
                                                <div class="mt-8">icon-image-filter-center-focus-weak</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-center-focus"></i>
                                                <div class="mt-8">icon-image-filter-center-focus</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-drama"></i>
                                                <div class="mt-8">icon-image-filter-drama</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-frames"></i>
                                                <div class="mt-8">icon-image-filter-frames</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-hdr"></i>
                                                <div class="mt-8">icon-image-filter-hdr</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-none"></i>
                                                <div class="mt-8">icon-image-filter-none</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-tilt-shift"></i>
                                                <div class="mt-8">icon-image-filter-tilt-shift</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter-vintage"></i>
                                                <div class="mt-8">icon-image-filter-vintage</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-filter"></i>
                                                <div class="mt-8">icon-image-filter</div>
                                            </div>

                                            <div>
                                                <i class="icon-image-mutliple"></i>
                                                <div class="mt-8">icon-image-mutliple</div>
                                            </div>

                                            <div>
                                                <i class="icon-image"></i>
                                                <div class="mt-8">icon-image</div>
                                            </div>

                                            <div>
                                                <i class="icon-import"></i>
                                                <div class="mt-8">icon-import</div>
                                            </div>

                                            <div>
                                                <i class="icon-inbox-arrow-down"></i>
                                                <div class="mt-8">icon-inbox-arrow-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-inbox-arrow-up"></i>
                                                <div class="mt-8">icon-inbox-arrow-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-inbox"></i>
                                                <div class="mt-8">icon-inbox</div>
                                            </div>

                                            <div>
                                                <i class="icon-incognito"></i>
                                                <div class="mt-8">icon-incognito</div>
                                            </div>

                                            <div>
                                                <i class="icon-indent"></i>
                                                <div class="mt-8">icon-indent</div>
                                            </div>

                                            <div>
                                                <i class="icon-infinity"></i>
                                                <div class="mt-8">icon-infinity</div>
                                            </div>

                                            <div>
                                                <i class="icon-information-outline"></i>
                                                <div class="mt-8">icon-information-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-information-variant"></i>
                                                <div class="mt-8">icon-information-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-information"></i>
                                                <div class="mt-8">icon-information</div>
                                            </div>

                                            <div>
                                                <i class="icon-instagram"></i>
                                                <div class="mt-8">icon-instagram</div>
                                            </div>

                                            <div>
                                                <i class="icon-instapaper"></i>
                                                <div class="mt-8">icon-instapaper</div>
                                            </div>

                                            <div>
                                                <i class="icon-internet-explorer"></i>
                                                <div class="mt-8">icon-internet-explorer</div>
                                            </div>

                                            <div>
                                                <i class="icon-invert-colors"></i>
                                                <div class="mt-8">icon-invert-colors</div>
                                            </div>

                                            <div>
                                                <i class="icon-itunes"></i>
                                                <div class="mt-8">icon-itunes</div>
                                            </div>

                                            <div>
                                                <i class="icon-jeepney"></i>
                                                <div class="mt-8">icon-jeepney</div>
                                            </div>

                                            <div>
                                                <i class="icon-jira"></i>
                                                <div class="mt-8">icon-jira</div>
                                            </div>

                                            <div>
                                                <i class="icon-jsfiddle"></i>
                                                <div class="mt-8">icon-jsfiddle</div>
                                            </div>

                                            <div>
                                                <i class="icon-json"></i>
                                                <div class="mt-8">icon-json</div>
                                            </div>

                                            <div>
                                                <i class="icon-keg"></i>
                                                <div class="mt-8">icon-keg</div>
                                            </div>

                                            <div>
                                                <i class="icon-kettle"></i>
                                                <div class="mt-8">icon-kettle</div>
                                            </div>

                                            <div>
                                                <i class="icon-key-change"></i>
                                                <div class="mt-8">icon-key-change</div>
                                            </div>

                                            <div>
                                                <i class="icon-key-minus"></i>
                                                <div class="mt-8">icon-key-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-key-plus"></i>
                                                <div class="mt-8">icon-key-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-key-remove"></i>
                                                <div class="mt-8">icon-key-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-key-variant"></i>
                                                <div class="mt-8">icon-key-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-key"></i>
                                                <div class="mt-8">icon-key</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard-backspace"></i>
                                                <div class="mt-8">icon-keyboard-backspace</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard-caps"></i>
                                                <div class="mt-8">icon-keyboard-caps</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard-close"></i>
                                                <div class="mt-8">icon-keyboard-close</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard-off"></i>
                                                <div class="mt-8">icon-keyboard-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard-return"></i>
                                                <div class="mt-8">icon-keyboard-return</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard-tab"></i>
                                                <div class="mt-8">icon-keyboard-tab</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard-variant"></i>
                                                <div class="mt-8">icon-keyboard-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-keyboard"></i>
                                                <div class="mt-8">icon-keyboard</div>
                                            </div>

                                            <div>
                                                <i class="icon-kickstarter"></i>
                                                <div class="mt-8">icon-kickstarter</div>
                                            </div>

                                            <div>
                                                <i class="icon-kodi"></i>
                                                <div class="mt-8">icon-kodi</div>
                                            </div>

                                            <div>
                                                <i class="icon-label-outline"></i>
                                                <div class="mt-8">icon-label-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-label"></i>
                                                <div class="mt-8">icon-label</div>
                                            </div>

                                            <div>
                                                <i class="icon-lambda"></i>
                                                <div class="mt-8">icon-lambda</div>
                                            </div>

                                            <div>
                                                <i class="icon-lamp"></i>
                                                <div class="mt-8">icon-lamp</div>
                                            </div>

                                            <div>
                                                <i class="icon-lan-connect"></i>
                                                <div class="mt-8">icon-lan-connect</div>
                                            </div>

                                            <div>
                                                <i class="icon-lan-disconnect"></i>
                                                <div class="mt-8">icon-lan-disconnect</div>
                                            </div>

                                            <div>
                                                <i class="icon-lan-pending"></i>
                                                <div class="mt-8">icon-lan-pending</div>
                                            </div>

                                            <div>
                                                <i class="icon-lan"></i>
                                                <div class="mt-8">icon-lan</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-c"></i>
                                                <div class="mt-8">icon-language-c</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-cpp"></i>
                                                <div class="mt-8">icon-language-cpp</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-csharp"></i>
                                                <div class="mt-8">icon-language-csharp</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-css3"></i>
                                                <div class="mt-8">icon-language-css3</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-html5"></i>
                                                <div class="mt-8">icon-language-html5</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-javascript"></i>
                                                <div class="mt-8">icon-language-javascript</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-php"></i>
                                                <div class="mt-8">icon-language-php</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-python-text"></i>
                                                <div class="mt-8">icon-language-python-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-python"></i>
                                                <div class="mt-8">icon-language-python</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-swift"></i>
                                                <div class="mt-8">icon-language-swift</div>
                                            </div>

                                            <div>
                                                <i class="icon-language-typescript"></i>
                                                <div class="mt-8">icon-language-typescript</div>
                                            </div>

                                            <div>
                                                <i class="icon-laptop-chromebook"></i>
                                                <div class="mt-8">icon-laptop-chromebook</div>
                                            </div>

                                            <div>
                                                <i class="icon-laptop-mac"></i>
                                                <div class="mt-8">icon-laptop-mac</div>
                                            </div>

                                            <div>
                                                <i class="icon-laptop-off"></i>
                                                <div class="mt-8">icon-laptop-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-laptop-windows"></i>
                                                <div class="mt-8">icon-laptop-windows</div>
                                            </div>

                                            <div>
                                                <i class="icon-laptop"></i>
                                                <div class="mt-8">icon-laptop</div>
                                            </div>

                                            <div>
                                                <i class="icon-lastfm"></i>
                                                <div class="mt-8">icon-lastfm</div>
                                            </div>

                                            <div>
                                                <i class="icon-launch"></i>
                                                <div class="mt-8">icon-launch</div>
                                            </div>

                                            <div>
                                                <i class="icon-layers-off"></i>
                                                <div class="mt-8">icon-layers-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-layers"></i>
                                                <div class="mt-8">icon-layers</div>
                                            </div>

                                            <div>
                                                <i class="icon-lead-pencil"></i>
                                                <div class="mt-8">icon-lead-pencil</div>
                                            </div>

                                            <div>
                                                <i class="icon-leaf"></i>
                                                <div class="mt-8">icon-leaf</div>
                                            </div>

                                            <div>
                                                <i class="icon-led-off"></i>
                                                <div class="mt-8">icon-led-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-led-on"></i>
                                                <div class="mt-8">icon-led-on</div>
                                            </div>

                                            <div>
                                                <i class="icon-led-outline"></i>
                                                <div class="mt-8">icon-led-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-led-variant-off"></i>
                                                <div class="mt-8">icon-led-variant-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-led-variant-on"></i>
                                                <div class="mt-8">icon-led-variant-on</div>
                                            </div>

                                            <div>
                                                <i class="icon-led-variant-outline"></i>
                                                <div class="mt-8">icon-led-variant-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-library-books"></i>
                                                <div class="mt-8">icon-library-books</div>
                                            </div>

                                            <div>
                                                <i class="icon-library-music"></i>
                                                <div class="mt-8">icon-library-music</div>
                                            </div>

                                            <div>
                                                <i class="icon-library-plus"></i>
                                                <div class="mt-8">icon-library-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-library"></i>
                                                <div class="mt-8">icon-library</div>
                                            </div>

                                            <div>
                                                <i class="icon-lightbulb-on-outline"></i>
                                                <div class="mt-8">icon-lightbulb-on-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-lightbulb-on"></i>
                                                <div class="mt-8">icon-lightbulb-on</div>
                                            </div>

                                            <div>
                                                <i class="icon-lightbulb-outline"></i>
                                                <div class="mt-8">icon-lightbulb-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-lightbulb"></i>
                                                <div class="mt-8">icon-lightbulb</div>
                                            </div>

                                            <div>
                                                <i class="icon-link-off"></i>
                                                <div class="mt-8">icon-link-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-link-variant-off"></i>
                                                <div class="mt-8">icon-link-variant-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-link-variant"></i>
                                                <div class="mt-8">icon-link-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-link"></i>
                                                <div class="mt-8">icon-link</div>
                                            </div>

                                            <div>
                                                <i class="icon-linkedin-box"></i>
                                                <div class="mt-8">icon-linkedin-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-linkedin"></i>
                                                <div class="mt-8">icon-linkedin</div>
                                            </div>

                                            <div>
                                                <i class="icon-linode"></i>
                                                <div class="mt-8">icon-linode</div>
                                            </div>

                                            <div>
                                                <i class="icon-linux"></i>
                                                <div class="mt-8">icon-linux</div>
                                            </div>

                                            <div>
                                                <i class="icon-loading"></i>
                                                <div class="mt-8">icon-loading</div>
                                            </div>

                                            <div>
                                                <i class="icon-lock-outline"></i>
                                                <div class="mt-8">icon-lock-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-lock-plus"></i>
                                                <div class="mt-8">icon-lock-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-lock-reset"></i>
                                                <div class="mt-8">icon-lock-reset</div>
                                            </div>

                                            <div>
                                                <i class="icon-lock-screen"></i>
                                                <div class="mt-8">icon-lock-screen</div>
                                            </div>

                                            <div>
                                                <i class="icon-lock-unlocked-outline"></i>
                                                <div class="mt-8">icon-lock-unlocked-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-lock-unlocked"></i>
                                                <div class="mt-8">icon-lock-unlocked</div>
                                            </div>

                                            <div>
                                                <i class="icon-lock"></i>
                                                <div class="mt-8">icon-lock</div>
                                            </div>

                                            <div>
                                                <i class="icon-login-variant"></i>
                                                <div class="mt-8">icon-login-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-login"></i>
                                                <div class="mt-8">icon-login</div>
                                            </div>

                                            <div>
                                                <i class="icon-logout-variant"></i>
                                                <div class="mt-8">icon-logout-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-logout"></i>
                                                <div class="mt-8">icon-logout</div>
                                            </div>

                                            <div>
                                                <i class="icon-looks"></i>
                                                <div class="mt-8">icon-looks</div>
                                            </div>

                                            <div>
                                                <i class="icon-loop"></i>
                                                <div class="mt-8">icon-loop</div>
                                            </div>

                                            <div>
                                                <i class="icon-loupe"></i>
                                                <div class="mt-8">icon-loupe</div>
                                            </div>

                                            <div>
                                                <i class="icon-lumx"></i>
                                                <div class="mt-8">icon-lumx</div>
                                            </div>

                                            <div>
                                                <i class="icon-magnet-on"></i>
                                                <div class="mt-8">icon-magnet-on</div>
                                            </div>

                                            <div>
                                                <i class="icon-magnet"></i>
                                                <div class="mt-8">icon-magnet</div>
                                            </div>

                                            <div>
                                                <i class="icon-magnify-minus-outline"></i>
                                                <div class="mt-8">icon-magnify-minus-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-magnify-minus"></i>
                                                <div class="mt-8">icon-magnify-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-magnify-plus-outline"></i>
                                                <div class="mt-8">icon-magnify-plus-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-magnify-plus"></i>
                                                <div class="mt-8">icon-magnify-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-magnify"></i>
                                                <div class="mt-8">icon-magnify</div>
                                            </div>

                                            <div>
                                                <i class="icon-mail-ru"></i>
                                                <div class="mt-8">icon-mail-ru</div>
                                            </div>

                                            <div>
                                                <i class="icon-mailbox"></i>
                                                <div class="mt-8">icon-mailbox</div>
                                            </div>

                                            <div>
                                                <i class="icon-map-marker-circle"></i>
                                                <div class="mt-8">icon-map-marker-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-map-marker-minus"></i>
                                                <div class="mt-8">icon-map-marker-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-map-marker-multiple"></i>
                                                <div class="mt-8">icon-map-marker-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-map-marker-off"></i>
                                                <div class="mt-8">icon-map-marker-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-map-marker-plus"></i>
                                                <div class="mt-8">icon-map-marker-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-map-marker-radius"></i>
                                                <div class="mt-8">icon-map-marker-radius</div>
                                            </div>

                                            <div>
                                                <i class="icon-map-marker"></i>
                                                <div class="mt-8">icon-map-marker</div>
                                            </div>

                                            <div>
                                                <i class="icon-map"></i>
                                                <div class="mt-8">icon-map</div>
                                            </div>

                                            <div>
                                                <i class="icon-margin"></i>
                                                <div class="mt-8">icon-margin</div>
                                            </div>

                                            <div>
                                                <i class="icon-markdown"></i>
                                                <div class="mt-8">icon-markdown</div>
                                            </div>

                                            <div>
                                                <i class="icon-marker-check"></i>
                                                <div class="mt-8">icon-marker-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-marker"></i>
                                                <div class="mt-8">icon-marker</div>
                                            </div>

                                            <div>
                                                <i class="icon-martini"></i>
                                                <div class="mt-8">icon-martini</div>
                                            </div>

                                            <div>
                                                <i class="icon-material-ui"></i>
                                                <div class="mt-8">icon-material-ui</div>
                                            </div>

                                            <div>
                                                <i class="icon-matrix"></i>
                                                <div class="mt-8">icon-matrix</div>
                                            </div>

                                            <div>
                                                <i class="icon-maxcdn"></i>
                                                <div class="mt-8">icon-maxcdn</div>
                                            </div>

                                            <div>
                                                <i class="icon-medical-bag"></i>
                                                <div class="mt-8">icon-medical-bag</div>
                                            </div>

                                            <div>
                                                <i class="icon-medium"></i>
                                                <div class="mt-8">icon-medium</div>
                                            </div>

                                            <div>
                                                <i class="icon-memory"></i>
                                                <div class="mt-8">icon-memory</div>
                                            </div>

                                            <div>
                                                <i class="icon-menu-down-outline"></i>
                                                <div class="mt-8">icon-menu-down-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-menu-down"></i>
                                                <div class="mt-8">icon-menu-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-menu-left"></i>
                                                <div class="mt-8">icon-menu-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-menu-right"></i>
                                                <div class="mt-8">icon-menu-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-menu-up-outline"></i>
                                                <div class="mt-8">icon-menu-up-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-menu-up"></i>
                                                <div class="mt-8">icon-menu-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-menu"></i>
                                                <div class="mt-8">icon-menu</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-alert"></i>
                                                <div class="mt-8">icon-message-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-bulleted-off"></i>
                                                <div class="mt-8">icon-message-bulleted-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-bulleted"></i>
                                                <div class="mt-8">icon-message-bulleted</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-draw"></i>
                                                <div class="mt-8">icon-message-draw</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-image"></i>
                                                <div class="mt-8">icon-message-image</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-outline"></i>
                                                <div class="mt-8">icon-message-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-plus"></i>
                                                <div class="mt-8">icon-message-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-processing"></i>
                                                <div class="mt-8">icon-message-processing</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-reply-text"></i>
                                                <div class="mt-8">icon-message-reply-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-reply"></i>
                                                <div class="mt-8">icon-message-reply</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-settings-variant"></i>
                                                <div class="mt-8">icon-message-settings-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-settings"></i>
                                                <div class="mt-8">icon-message-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-text-outline"></i>
                                                <div class="mt-8">icon-message-text-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-text"></i>
                                                <div class="mt-8">icon-message-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-message-video"></i>
                                                <div class="mt-8">icon-message-video</div>
                                            </div>

                                            <div>
                                                <i class="icon-message"></i>
                                                <div class="mt-8">icon-message</div>
                                            </div>

                                            <div>
                                                <i class="icon-meteor"></i>
                                                <div class="mt-8">icon-meteor</div>
                                            </div>

                                            <div>
                                                <i class="icon-microphone-off"></i>
                                                <div class="mt-8">icon-microphone-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-microphone-outline"></i>
                                                <div class="mt-8">icon-microphone-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-microphone-settings"></i>
                                                <div class="mt-8">icon-microphone-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-microphone-variant-off"></i>
                                                <div class="mt-8">icon-microphone-variant-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-microphone-variant"></i>
                                                <div class="mt-8">icon-microphone-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-microphone"></i>
                                                <div class="mt-8">icon-microphone</div>
                                            </div>

                                            <div>
                                                <i class="icon-microscope"></i>
                                                <div class="mt-8">icon-microscope</div>
                                            </div>

                                            <div>
                                                <i class="icon-microsoft"></i>
                                                <div class="mt-8">icon-microsoft</div>
                                            </div>

                                            <div>
                                                <i class="icon-minecraft"></i>
                                                <div class="mt-8">icon-minecraft</div>
                                            </div>

                                            <div>
                                                <i class="icon-minus-box-outline"></i>
                                                <div class="mt-8">icon-minus-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-minus-box"></i>
                                                <div class="mt-8">icon-minus-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-minus-circle-outline"></i>
                                                <div class="mt-8">icon-minus-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-minus-circle"></i>
                                                <div class="mt-8">icon-minus-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-minus-network"></i>
                                                <div class="mt-8">icon-minus-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-minus"></i>
                                                <div class="mt-8">icon-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-mixcloud"></i>
                                                <div class="mt-8">icon-mixcloud</div>
                                            </div>

                                            <div>
                                                <i class="icon-monitor-multiple"></i>
                                                <div class="mt-8">icon-monitor-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-monitor"></i>
                                                <div class="mt-8">icon-monitor</div>
                                            </div>

                                            <div>
                                                <i class="icon-more"></i>
                                                <div class="mt-8">icon-more</div>
                                            </div>

                                            <div>
                                                <i class="icon-mouse-off"></i>
                                                <div class="mt-8">icon-mouse-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-mouse-variant-off"></i>
                                                <div class="mt-8">icon-mouse-variant-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-mouse-variant"></i>
                                                <div class="mt-8">icon-mouse-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-mouse"></i>
                                                <div class="mt-8">icon-mouse</div>
                                            </div>

                                            <div>
                                                <i class="icon-move-resize-variant"></i>
                                                <div class="mt-8">icon-move-resize-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-move-resize"></i>
                                                <div class="mt-8">icon-move-resize</div>
                                            </div>

                                            <div>
                                                <i class="icon-movie"></i>
                                                <div class="mt-8">icon-movie</div>
                                            </div>

                                            <div>
                                                <i class="icon-multiplication-box"></i>
                                                <div class="mt-8">icon-multiplication-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-multiplication"></i>
                                                <div class="mt-8">icon-multiplication</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-box-outline"></i>
                                                <div class="mt-8">icon-music-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-box"></i>
                                                <div class="mt-8">icon-music-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-circle"></i>
                                                <div class="mt-8">icon-music-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-bluetooth-off"></i>
                                                <div class="mt-8">icon-music-note-bluetooth-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-bluetooth"></i>
                                                <div class="mt-8">icon-music-note-bluetooth</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-eighth"></i>
                                                <div class="mt-8">icon-music-note-eighth</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-half"></i>
                                                <div class="mt-8">icon-music-note-half</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-off"></i>
                                                <div class="mt-8">icon-music-note-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-quarter"></i>
                                                <div class="mt-8">icon-music-note-quarter</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-sixteenth"></i>
                                                <div class="mt-8">icon-music-note-sixteenth</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note-whole"></i>
                                                <div class="mt-8">icon-music-note-whole</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-note"></i>
                                                <div class="mt-8">icon-music-note</div>
                                            </div>

                                            <div>
                                                <i class="icon-music-off"></i>
                                                <div class="mt-8">icon-music-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-music"></i>
                                                <div class="mt-8">icon-music</div>
                                            </div>

                                            <div>
                                                <i class="icon-nature-people"></i>
                                                <div class="mt-8">icon-nature-people</div>
                                            </div>

                                            <div>
                                                <i class="icon-nature"></i>
                                                <div class="mt-8">icon-nature</div>
                                            </div>

                                            <div>
                                                <i class="icon-navigation"></i>
                                                <div class="mt-8">icon-navigation</div>
                                            </div>

                                            <div>
                                                <i class="icon-near-me"></i>
                                                <div class="mt-8">icon-near-me</div>
                                            </div>

                                            <div>
                                                <i class="icon-needle"></i>
                                                <div class="mt-8">icon-needle</div>
                                            </div>

                                            <div>
                                                <i class="icon-nest-protect"></i>
                                                <div class="mt-8">icon-nest-protect</div>
                                            </div>

                                            <div>
                                                <i class="icon-nest-thermostat"></i>
                                                <div class="mt-8">icon-nest-thermostat</div>
                                            </div>

                                            <div>
                                                <i class="icon-netflix"></i>
                                                <div class="mt-8">icon-netflix</div>
                                            </div>

                                            <div>
                                                <i class="icon-network-download"></i>
                                                <div class="mt-8">icon-network-download</div>
                                            </div>

                                            <div>
                                                <i class="icon-network-question"></i>
                                                <div class="mt-8">icon-network-question</div>
                                            </div>

                                            <div>
                                                <i class="icon-network-upload"></i>
                                                <div class="mt-8">icon-network-upload</div>
                                            </div>

                                            <div>
                                                <i class="icon-network"></i>
                                                <div class="mt-8">icon-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-new-box"></i>
                                                <div class="mt-8">icon-new-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-newspaper"></i>
                                                <div class="mt-8">icon-newspaper</div>
                                            </div>

                                            <div>
                                                <i class="icon-nfc-tap"></i>
                                                <div class="mt-8">icon-nfc-tap</div>
                                            </div>

                                            <div>
                                                <i class="icon-nfc-variant"></i>
                                                <div class="mt-8">icon-nfc-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-nfc"></i>
                                                <div class="mt-8">icon-nfc</div>
                                            </div>

                                            <div>
                                                <i class="icon-ninja"></i>
                                                <div class="mt-8">icon-ninja</div>
                                            </div>

                                            <div>
                                                <i class="icon-no"></i>
                                                <div class="mt-8">icon-no</div>
                                            </div>

                                            <div>
                                                <i class="icon-nodejs"></i>
                                                <div class="mt-8">icon-nodejs</div>
                                            </div>

                                            <div>
                                                <i class="icon-not-equal"></i>
                                                <div class="mt-8">icon-not-equal</div>
                                            </div>

                                            <div>
                                                <i class="icon-note-multiple-outline"></i>
                                                <div class="mt-8">icon-note-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-note-multiple"></i>
                                                <div class="mt-8">icon-note-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-note-outline"></i>
                                                <div class="mt-8">icon-note-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-note-plus-outline"></i>
                                                <div class="mt-8">icon-note-plus-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-note-plus"></i>
                                                <div class="mt-8">icon-note-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-note-text"></i>
                                                <div class="mt-8">icon-note-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-note"></i>
                                                <div class="mt-8">icon-note</div>
                                            </div>

                                            <div>
                                                <i class="icon-notification-clear-all"></i>
                                                <div class="mt-8">icon-notification-clear-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-npm"></i>
                                                <div class="mt-8">icon-npm</div>
                                            </div>

                                            <div>
                                                <i class="icon-nuke"></i>
                                                <div class="mt-8">icon-nuke</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-0-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-0-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-0-box-outline"></i>
                                                <div class="mt-8">icon-numeric-0-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-0-box"></i>
                                                <div class="mt-8">icon-numeric-0-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-1-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-1-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-1-box-outline"></i>
                                                <div class="mt-8">icon-numeric-1-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-1-box"></i>
                                                <div class="mt-8">icon-numeric-1-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-2-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-2-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-2-box-outline"></i>
                                                <div class="mt-8">icon-numeric-2-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-2-box"></i>
                                                <div class="mt-8">icon-numeric-2-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-3-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-3-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-3-box-outline"></i>
                                                <div class="mt-8">icon-numeric-3-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-3-box"></i>
                                                <div class="mt-8">icon-numeric-3-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-4-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-4-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-4-box-outline"></i>
                                                <div class="mt-8">icon-numeric-4-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-4-box"></i>
                                                <div class="mt-8">icon-numeric-4-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-5-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-5-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-5-box-outline"></i>
                                                <div class="mt-8">icon-numeric-5-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-5-box"></i>
                                                <div class="mt-8">icon-numeric-5-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-6-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-6-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-6-box-outline"></i>
                                                <div class="mt-8">icon-numeric-6-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-6-box"></i>
                                                <div class="mt-8">icon-numeric-6-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-7-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-7-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-7-box-outline"></i>
                                                <div class="mt-8">icon-numeric-7-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-7-box"></i>
                                                <div class="mt-8">icon-numeric-7-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-8-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-8-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-8-box-outline"></i>
                                                <div class="mt-8">icon-numeric-8-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-8-box"></i>
                                                <div class="mt-8">icon-numeric-8-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-9-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-9-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-9-box-outline"></i>
                                                <div class="mt-8">icon-numeric-9-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-9-box"></i>
                                                <div class="mt-8">icon-numeric-9-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-9-plus-box-multiple-outline"></i>
                                                <div class="mt-8">icon-numeric-9-plus-box-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-9-plus-box-outline"></i>
                                                <div class="mt-8">icon-numeric-9-plus-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric-9-plus-box"></i>
                                                <div class="mt-8">icon-numeric-9-plus-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-numeric"></i>
                                                <div class="mt-8">icon-numeric</div>
                                            </div>

                                            <div>
                                                <i class="icon-nut"></i>
                                                <div class="mt-8">icon-nut</div>
                                            </div>

                                            <div>
                                                <i class="icon-nutriton"></i>
                                                <div class="mt-8">icon-nutriton</div>
                                            </div>

                                            <div>
                                                <i class="icon-oar"></i>
                                                <div class="mt-8">icon-oar</div>
                                            </div>

                                            <div>
                                                <i class="icon-octagon-outline"></i>
                                                <div class="mt-8">icon-octagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-octagon"></i>
                                                <div class="mt-8">icon-octagon</div>
                                            </div>

                                            <div>
                                                <i class="icon-octagram-outline"></i>
                                                <div class="mt-8">icon-octagram-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-octagram"></i>
                                                <div class="mt-8">icon-octagram</div>
                                            </div>

                                            <div>
                                                <i class="icon-odnoklassniki"></i>
                                                <div class="mt-8">icon-odnoklassniki</div>
                                            </div>

                                            <div>
                                                <i class="icon-office"></i>
                                                <div class="mt-8">icon-office</div>
                                            </div>

                                            <div>
                                                <i class="icon-oil-temperature"></i>
                                                <div class="mt-8">icon-oil-temperature</div>
                                            </div>

                                            <div>
                                                <i class="icon-oil"></i>
                                                <div class="mt-8">icon-oil</div>
                                            </div>

                                            <div>
                                                <i class="icon-omega"></i>
                                                <div class="mt-8">icon-omega</div>
                                            </div>

                                            <div>
                                                <i class="icon-onedrive"></i>
                                                <div class="mt-8">icon-onedrive</div>
                                            </div>

                                            <div>
                                                <i class="icon-onenote"></i>
                                                <div class="mt-8">icon-onenote</div>
                                            </div>

                                            <div>
                                                <i class="icon-opacity"></i>
                                                <div class="mt-8">icon-opacity</div>
                                            </div>

                                            <div>
                                                <i class="icon-open-in-app"></i>
                                                <div class="mt-8">icon-open-in-app</div>
                                            </div>

                                            <div>
                                                <i class="icon-open-in-new"></i>
                                                <div class="mt-8">icon-open-in-new</div>
                                            </div>

                                            <div>
                                                <i class="icon-openid"></i>
                                                <div class="mt-8">icon-openid</div>
                                            </div>

                                            <div>
                                                <i class="icon-opera"></i>
                                                <div class="mt-8">icon-opera</div>
                                            </div>

                                            <div>
                                                <i class="icon-orbit"></i>
                                                <div class="mt-8">icon-orbit</div>
                                            </div>

                                            <div>
                                                <i class="icon-ornament-variant"></i>
                                                <div class="mt-8">icon-ornament-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-ornament"></i>
                                                <div class="mt-8">icon-ornament</div>
                                            </div>

                                            <div>
                                                <i class="icon-outbox"></i>
                                                <div class="mt-8">icon-outbox</div>
                                            </div>

                                            <div>
                                                <i class="icon-outdent"></i>
                                                <div class="mt-8">icon-outdent</div>
                                            </div>

                                            <div>
                                                <i class="icon-owl"></i>
                                                <div class="mt-8">icon-owl</div>
                                            </div>

                                            <div>
                                                <i class="icon-package-down"></i>
                                                <div class="mt-8">icon-package-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-package-up"></i>
                                                <div class="mt-8">icon-package-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-package-variant-closed"></i>
                                                <div class="mt-8">icon-package-variant-closed</div>
                                            </div>

                                            <div>
                                                <i class="icon-package-variant"></i>
                                                <div class="mt-8">icon-package-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-package"></i>
                                                <div class="mt-8">icon-package</div>
                                            </div>

                                            <div>
                                                <i class="icon-page-first"></i>
                                                <div class="mt-8">icon-page-first</div>
                                            </div>

                                            <div>
                                                <i class="icon-page-last"></i>
                                                <div class="mt-8">icon-page-last</div>
                                            </div>

                                            <div>
                                                <i class="icon-page-layout-body"></i>
                                                <div class="mt-8">icon-page-layout-body</div>
                                            </div>

                                            <div>
                                                <i class="icon-page-layout-footer"></i>
                                                <div class="mt-8">icon-page-layout-footer</div>
                                            </div>

                                            <div>
                                                <i class="icon-page-layout-header"></i>
                                                <div class="mt-8">icon-page-layout-header</div>
                                            </div>

                                            <div>
                                                <i class="icon-page-layout-sidebar-left"></i>
                                                <div class="mt-8">icon-page-layout-sidebar-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-page-layout-sidebar-right"></i>
                                                <div class="mt-8">icon-page-layout-sidebar-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-palette-advanced"></i>
                                                <div class="mt-8">icon-palette-advanced</div>
                                            </div>

                                            <div>
                                                <i class="icon-palette"></i>
                                                <div class="mt-8">icon-palette</div>
                                            </div>

                                            <div>
                                                <i class="icon-panda"></i>
                                                <div class="mt-8">icon-panda</div>
                                            </div>

                                            <div>
                                                <i class="icon-pandora"></i>
                                                <div class="mt-8">icon-pandora</div>
                                            </div>

                                            <div>
                                                <i class="icon-panorama-fisheye"></i>
                                                <div class="mt-8">icon-panorama-fisheye</div>
                                            </div>

                                            <div>
                                                <i class="icon-panorama-horizontal"></i>
                                                <div class="mt-8">icon-panorama-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-panorama-vertical"></i>
                                                <div class="mt-8">icon-panorama-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-panorama-wide-angle"></i>
                                                <div class="mt-8">icon-panorama-wide-angle</div>
                                            </div>

                                            <div>
                                                <i class="icon-panorama"></i>
                                                <div class="mt-8">icon-panorama</div>
                                            </div>

                                            <div>
                                                <i class="icon-paper-cut-vertical"></i>
                                                <div class="mt-8">icon-paper-cut-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-paperclip"></i>
                                                <div class="mt-8">icon-paperclip</div>
                                            </div>

                                            <div>
                                                <i class="icon-parking"></i>
                                                <div class="mt-8">icon-parking</div>
                                            </div>

                                            <div>
                                                <i class="icon-pause-circle-outline"></i>
                                                <div class="mt-8">icon-pause-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-pause-circle"></i>
                                                <div class="mt-8">icon-pause-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-pause-octagon-outline"></i>
                                                <div class="mt-8">icon-pause-octagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-pause-octagon"></i>
                                                <div class="mt-8">icon-pause-octagon</div>
                                            </div>

                                            <div>
                                                <i class="icon-pause"></i>
                                                <div class="mt-8">icon-pause</div>
                                            </div>

                                            <div>
                                                <i class="icon-paw-off"></i>
                                                <div class="mt-8">icon-paw-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-paw"></i>
                                                <div class="mt-8">icon-paw</div>
                                            </div>

                                            <div>
                                                <i class="icon-pen"></i>
                                                <div class="mt-8">icon-pen</div>
                                            </div>

                                            <div>
                                                <i class="icon-pencil-box-outline"></i>
                                                <div class="mt-8">icon-pencil-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-pencil-box"></i>
                                                <div class="mt-8">icon-pencil-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-pencil-circle-outline"></i>
                                                <div class="mt-8">icon-pencil-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-pencil-circle"></i>
                                                <div class="mt-8">icon-pencil-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-pencil-lock"></i>
                                                <div class="mt-8">icon-pencil-lock</div>
                                            </div>

                                            <div>
                                                <i class="icon-pencil-off"></i>
                                                <div class="mt-8">icon-pencil-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-pencil"></i>
                                                <div class="mt-8">icon-pencil</div>
                                            </div>

                                            <div>
                                                <i class="icon-pentagon-outline"></i>
                                                <div class="mt-8">icon-pentagon-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-pentagon"></i>
                                                <div class="mt-8">icon-pentagon</div>
                                            </div>

                                            <div>
                                                <i class="icon-people"></i>
                                                <div class="mt-8">icon-people</div>
                                            </div>

                                            <div>
                                                <i class="icon-percent"></i>
                                                <div class="mt-8">icon-percent</div>
                                            </div>

                                            <div>
                                                <i class="icon-periscope"></i>
                                                <div class="mt-8">icon-periscope</div>
                                            </div>

                                            <div>
                                                <i class="icon-person-box"></i>
                                                <div class="mt-8">icon-person-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-person-minus"></i>
                                                <div class="mt-8">icon-person-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-person-plus"></i>
                                                <div class="mt-8">icon-person-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-pharmacy"></i>
                                                <div class="mt-8">icon-pharmacy</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-bluetooth"></i>
                                                <div class="mt-8">icon-phone-bluetooth</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-classic"></i>
                                                <div class="mt-8">icon-phone-classic</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-dots"></i>
                                                <div class="mt-8">icon-phone-dots</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-forward"></i>
                                                <div class="mt-8">icon-phone-forward</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-hangup"></i>
                                                <div class="mt-8">icon-phone-hangup</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-in-talk"></i>
                                                <div class="mt-8">icon-phone-in-talk</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-incoming"></i>
                                                <div class="mt-8">icon-phone-incoming</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-locked"></i>
                                                <div class="mt-8">icon-phone-locked</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-log"></i>
                                                <div class="mt-8">icon-phone-log</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-minus"></i>
                                                <div class="mt-8">icon-phone-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-missed"></i>
                                                <div class="mt-8">icon-phone-missed</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-outgoing"></i>
                                                <div class="mt-8">icon-phone-outgoing</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-paused"></i>
                                                <div class="mt-8">icon-phone-paused</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-plus"></i>
                                                <div class="mt-8">icon-phone-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone-voip"></i>
                                                <div class="mt-8">icon-phone-voip</div>
                                            </div>

                                            <div>
                                                <i class="icon-phone"></i>
                                                <div class="mt-8">icon-phone</div>
                                            </div>

                                            <div>
                                                <i class="icon-pi-box"></i>
                                                <div class="mt-8">icon-pi-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-pi"></i>
                                                <div class="mt-8">icon-pi</div>
                                            </div>

                                            <div>
                                                <i class="icon-piano"></i>
                                                <div class="mt-8">icon-piano</div>
                                            </div>

                                            <div>
                                                <i class="icon-picture"></i>
                                                <div class="mt-8">icon-picture</div>
                                            </div>

                                            <div>
                                                <i class="icon-pig"></i>
                                                <div class="mt-8">icon-pig</div>
                                            </div>

                                            <div>
                                                <i class="icon-pill"></i>
                                                <div class="mt-8">icon-pill</div>
                                            </div>

                                            <div>
                                                <i class="icon-pillar"></i>
                                                <div class="mt-8">icon-pillar</div>
                                            </div>

                                            <div>
                                                <i class="icon-pin-off"></i>
                                                <div class="mt-8">icon-pin-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-pin"></i>
                                                <div class="mt-8">icon-pin</div>
                                            </div>

                                            <div>
                                                <i class="icon-pine-tree-box"></i>
                                                <div class="mt-8">icon-pine-tree-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-pine-tree"></i>
                                                <div class="mt-8">icon-pine-tree</div>
                                            </div>

                                            <div>
                                                <i class="icon-pinterest-box"></i>
                                                <div class="mt-8">icon-pinterest-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-pinterest"></i>
                                                <div class="mt-8">icon-pinterest</div>
                                            </div>

                                            <div>
                                                <i class="icon-pistol"></i>
                                                <div class="mt-8">icon-pistol</div>
                                            </div>

                                            <div>
                                                <i class="icon-pizza"></i>
                                                <div class="mt-8">icon-pizza</div>
                                            </div>

                                            <div>
                                                <i class="icon-plane-shield"></i>
                                                <div class="mt-8">icon-plane-shield</div>
                                            </div>

                                            <div>
                                                <i class="icon-plane"></i>
                                                <div class="mt-8">icon-plane</div>
                                            </div>

                                            <div>
                                                <i class="icon-play-box-outline"></i>
                                                <div class="mt-8">icon-play-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-play-circle-outline"></i>
                                                <div class="mt-8">icon-play-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-play-circle"></i>
                                                <div class="mt-8">icon-play-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-play-pause"></i>
                                                <div class="mt-8">icon-play-pause</div>
                                            </div>

                                            <div>
                                                <i class="icon-play-protected-content"></i>
                                                <div class="mt-8">icon-play-protected-content</div>
                                            </div>

                                            <div>
                                                <i class="icon-play"></i>
                                                <div class="mt-8">icon-play</div>
                                            </div>

                                            <div>
                                                <i class="icon-playlist-check"></i>
                                                <div class="mt-8">icon-playlist-check</div>
                                            </div>

                                            <div>
                                                <i class="icon-playlist-minus"></i>
                                                <div class="mt-8">icon-playlist-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-playlist-play"></i>
                                                <div class="mt-8">icon-playlist-play</div>
                                            </div>

                                            <div>
                                                <i class="icon-playlist-plus"></i>
                                                <div class="mt-8">icon-playlist-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-playlist-remove"></i>
                                                <div class="mt-8">icon-playlist-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-playstation"></i>
                                                <div class="mt-8">icon-playstation</div>
                                            </div>

                                            <div>
                                                <i class="icon-plex"></i>
                                                <div class="mt-8">icon-plex</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-box-outline"></i>
                                                <div class="mt-8">icon-plus-box-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-box"></i>
                                                <div class="mt-8">icon-plus-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-circle-multiple-outline"></i>
                                                <div class="mt-8">icon-plus-circle-multiple-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-circle-outline"></i>
                                                <div class="mt-8">icon-plus-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-circle"></i>
                                                <div class="mt-8">icon-plus-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-network"></i>
                                                <div class="mt-8">icon-plus-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-one"></i>
                                                <div class="mt-8">icon-plus-one</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus-outline"></i>
                                                <div class="mt-8">icon-plus-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-plus"></i>
                                                <div class="mt-8">icon-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-pocket"></i>
                                                <div class="mt-8">icon-pocket</div>
                                            </div>

                                            <div>
                                                <i class="icon-pokeball"></i>
                                                <div class="mt-8">icon-pokeball</div>
                                            </div>

                                            <div>
                                                <i class="icon-polaroid"></i>
                                                <div class="mt-8">icon-polaroid</div>
                                            </div>

                                            <div>
                                                <i class="icon-poll-box"></i>
                                                <div class="mt-8">icon-poll-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-poll"></i>
                                                <div class="mt-8">icon-poll</div>
                                            </div>

                                            <div>
                                                <i class="icon-polymer"></i>
                                                <div class="mt-8">icon-polymer</div>
                                            </div>

                                            <div>
                                                <i class="icon-pool"></i>
                                                <div class="mt-8">icon-pool</div>
                                            </div>

                                            <div>
                                                <i class="icon-popcorn"></i>
                                                <div class="mt-8">icon-popcorn</div>
                                            </div>

                                            <div>
                                                <i class="icon-pot-mix"></i>
                                                <div class="mt-8">icon-pot-mix</div>
                                            </div>

                                            <div>
                                                <i class="icon-pot"></i>
                                                <div class="mt-8">icon-pot</div>
                                            </div>

                                            <div>
                                                <i class="icon-pound-box"></i>
                                                <div class="mt-8">icon-pound-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-pound"></i>
                                                <div class="mt-8">icon-pound</div>
                                            </div>

                                            <div>
                                                <i class="icon-power-plug-off"></i>
                                                <div class="mt-8">icon-power-plug-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-power-plug"></i>
                                                <div class="mt-8">icon-power-plug</div>
                                            </div>

                                            <div>
                                                <i class="icon-power-settings"></i>
                                                <div class="mt-8">icon-power-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-power-socket"></i>
                                                <div class="mt-8">icon-power-socket</div>
                                            </div>

                                            <div>
                                                <i class="icon-power"></i>
                                                <div class="mt-8">icon-power</div>
                                            </div>

                                            <div>
                                                <i class="icon-prescription"></i>
                                                <div class="mt-8">icon-prescription</div>
                                            </div>

                                            <div>
                                                <i class="icon-presentation-play"></i>
                                                <div class="mt-8">icon-presentation-play</div>
                                            </div>

                                            <div>
                                                <i class="icon-presentation"></i>
                                                <div class="mt-8">icon-presentation</div>
                                            </div>

                                            <div>
                                                <i class="icon-printer-3d"></i>
                                                <div class="mt-8">icon-printer-3d</div>
                                            </div>

                                            <div>
                                                <i class="icon-printer-alert"></i>
                                                <div class="mt-8">icon-printer-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-printer-settings"></i>
                                                <div class="mt-8">icon-printer-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-printer"></i>
                                                <div class="mt-8">icon-printer</div>
                                            </div>

                                            <div>
                                                <i class="icon-priority-high"></i>
                                                <div class="mt-8">icon-priority-high</div>
                                            </div>

                                            <div>
                                                <i class="icon-priority-low"></i>
                                                <div class="mt-8">icon-priority-low</div>
                                            </div>

                                            <div>
                                                <i class="icon-professional-hexagon"></i>
                                                <div class="mt-8">icon-professional-hexagon</div>
                                            </div>

                                            <div>
                                                <i class="icon-projector-screen"></i>
                                                <div class="mt-8">icon-projector-screen</div>
                                            </div>

                                            <div>
                                                <i class="icon-projector"></i>
                                                <div class="mt-8">icon-projector</div>
                                            </div>

                                            <div>
                                                <i class="icon-publish"></i>
                                                <div class="mt-8">icon-publish</div>
                                            </div>

                                            <div>
                                                <i class="icon-pulse"></i>
                                                <div class="mt-8">icon-pulse</div>
                                            </div>

                                            <div>
                                                <i class="icon-puzzle"></i>
                                                <div class="mt-8">icon-puzzle</div>
                                            </div>

                                            <div>
                                                <i class="icon-qqchat"></i>
                                                <div class="mt-8">icon-qqchat</div>
                                            </div>

                                            <div>
                                                <i class="icon-qrcode-scan"></i>
                                                <div class="mt-8">icon-qrcode-scan</div>
                                            </div>

                                            <div>
                                                <i class="icon-qrcode"></i>
                                                <div class="mt-8">icon-qrcode</div>
                                            </div>

                                            <div>
                                                <i class="icon-quadcopter"></i>
                                                <div class="mt-8">icon-quadcopter</div>
                                            </div>

                                            <div>
                                                <i class="icon-quality-high"></i>
                                                <div class="mt-8">icon-quality-high</div>
                                            </div>

                                            <div>
                                                <i class="icon-question-mark-circle"></i>
                                                <div class="mt-8">icon-question-mark-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-quick-reply"></i>
                                                <div class="mt-8">icon-quick-reply</div>
                                            </div>

                                            <div>
                                                <i class="icon-quicktime"></i>
                                                <div class="mt-8">icon-quicktime</div>
                                            </div>

                                            <div>
                                                <i class="icon-rabbit"></i>
                                                <div class="mt-8">icon-rabbit</div>
                                            </div>

                                            <div>
                                                <i class="icon-radar"></i>
                                                <div class="mt-8">icon-radar</div>
                                            </div>

                                            <div>
                                                <i class="icon-radiator"></i>
                                                <div class="mt-8">icon-radiator</div>
                                            </div>

                                            <div>
                                                <i class="icon-radio-handheld"></i>
                                                <div class="mt-8">icon-radio-handheld</div>
                                            </div>

                                            <div>
                                                <i class="icon-radio-tower"></i>
                                                <div class="mt-8">icon-radio-tower</div>
                                            </div>

                                            <div>
                                                <i class="icon-radio"></i>
                                                <div class="mt-8">icon-radio</div>
                                            </div>

                                            <div>
                                                <i class="icon-radioactive"></i>
                                                <div class="mt-8">icon-radioactive</div>
                                            </div>

                                            <div>
                                                <i class="icon-radiobox-blank"></i>
                                                <div class="mt-8">icon-radiobox-blank</div>
                                            </div>

                                            <div>
                                                <i class="icon-radiobox-marked"></i>
                                                <div class="mt-8">icon-radiobox-marked</div>
                                            </div>

                                            <div>
                                                <i class="icon-raspberrypi"></i>
                                                <div class="mt-8">icon-raspberrypi</div>
                                            </div>

                                            <div>
                                                <i class="icon-ray-end-arrow"></i>
                                                <div class="mt-8">icon-ray-end-arrow</div>
                                            </div>

                                            <div>
                                                <i class="icon-ray-end"></i>
                                                <div class="mt-8">icon-ray-end</div>
                                            </div>

                                            <div>
                                                <i class="icon-ray-start-arrow"></i>
                                                <div class="mt-8">icon-ray-start-arrow</div>
                                            </div>

                                            <div>
                                                <i class="icon-ray-start-end"></i>
                                                <div class="mt-8">icon-ray-start-end</div>
                                            </div>

                                            <div>
                                                <i class="icon-ray-start"></i>
                                                <div class="mt-8">icon-ray-start</div>
                                            </div>

                                            <div>
                                                <i class="icon-ray-vertex"></i>
                                                <div class="mt-8">icon-ray-vertex</div>
                                            </div>

                                            <div>
                                                <i class="icon-rdio"></i>
                                                <div class="mt-8">icon-rdio</div>
                                            </div>

                                            <div>
                                                <i class="icon-react"></i>
                                                <div class="mt-8">icon-react</div>
                                            </div>

                                            <div>
                                                <i class="icon-read"></i>
                                                <div class="mt-8">icon-read</div>
                                            </div>

                                            <div>
                                                <i class="icon-readability"></i>
                                                <div class="mt-8">icon-readability</div>
                                            </div>

                                            <div>
                                                <i class="icon-receipt"></i>
                                                <div class="mt-8">icon-receipt</div>
                                            </div>

                                            <div>
                                                <i class="icon-record-rec"></i>
                                                <div class="mt-8">icon-record-rec</div>
                                            </div>

                                            <div>
                                                <i class="icon-record"></i>
                                                <div class="mt-8">icon-record</div>
                                            </div>

                                            <div>
                                                <i class="icon-recycle"></i>
                                                <div class="mt-8">icon-recycle</div>
                                            </div>

                                            <div>
                                                <i class="icon-reddit"></i>
                                                <div class="mt-8">icon-reddit</div>
                                            </div>

                                            <div>
                                                <i class="icon-redo-variant"></i>
                                                <div class="mt-8">icon-redo-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-redo"></i>
                                                <div class="mt-8">icon-redo</div>
                                            </div>

                                            <div>
                                                <i class="icon-refresh"></i>
                                                <div class="mt-8">icon-refresh</div>
                                            </div>

                                            <div>
                                                <i class="icon-relative-scale"></i>
                                                <div class="mt-8">icon-relative-scale</div>
                                            </div>

                                            <div>
                                                <i class="icon-reload"></i>
                                                <div class="mt-8">icon-reload</div>
                                            </div>

                                            <div>
                                                <i class="icon-remote"></i>
                                                <div class="mt-8">icon-remote</div>
                                            </div>

                                            <div>
                                                <i class="icon-rename-box"></i>
                                                <div class="mt-8">icon-rename-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-reorder-horizontal"></i>
                                                <div class="mt-8">icon-reorder-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-reorder-vertical"></i>
                                                <div class="mt-8">icon-reorder-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-repeat-off"></i>
                                                <div class="mt-8">icon-repeat-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-repeat-once"></i>
                                                <div class="mt-8">icon-repeat-once</div>
                                            </div>

                                            <div>
                                                <i class="icon-repeat"></i>
                                                <div class="mt-8">icon-repeat</div>
                                            </div>

                                            <div>
                                                <i class="icon-replay"></i>
                                                <div class="mt-8">icon-replay</div>
                                            </div>

                                            <div>
                                                <i class="icon-reply-all"></i>
                                                <div class="mt-8">icon-reply-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-reply"></i>
                                                <div class="mt-8">icon-reply</div>
                                            </div>

                                            <div>
                                                <i class="icon-reproduction"></i>
                                                <div class="mt-8">icon-reproduction</div>
                                            </div>

                                            <div>
                                                <i class="icon-resize-bottom-right"></i>
                                                <div class="mt-8">icon-resize-bottom-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-responsive"></i>
                                                <div class="mt-8">icon-responsive</div>
                                            </div>

                                            <div>
                                                <i class="icon-restart"></i>
                                                <div class="mt-8">icon-restart</div>
                                            </div>

                                            <div>
                                                <i class="icon-restore"></i>
                                                <div class="mt-8">icon-restore</div>
                                            </div>

                                            <div>
                                                <i class="icon-rewind-outline"></i>
                                                <div class="mt-8">icon-rewind-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-rewind"></i>
                                                <div class="mt-8">icon-rewind</div>
                                            </div>

                                            <div>
                                                <i class="icon-rhombus-outline"></i>
                                                <div class="mt-8">icon-rhombus-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-rhombus"></i>
                                                <div class="mt-8">icon-rhombus</div>
                                            </div>

                                            <div>
                                                <i class="icon-ribbon"></i>
                                                <div class="mt-8">icon-ribbon</div>
                                            </div>

                                            <div>
                                                <i class="icon-road-variant"></i>
                                                <div class="mt-8">icon-road-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-road"></i>
                                                <div class="mt-8">icon-road</div>
                                            </div>

                                            <div>
                                                <i class="icon-robot"></i>
                                                <div class="mt-8">icon-robot</div>
                                            </div>

                                            <div>
                                                <i class="icon-rocket"></i>
                                                <div class="mt-8">icon-rocket</div>
                                            </div>

                                            <div>
                                                <i class="icon-roomba"></i>
                                                <div class="mt-8">icon-roomba</div>
                                            </div>

                                            <div>
                                                <i class="icon-rotate-3d"></i>
                                                <div class="mt-8">icon-rotate-3d</div>
                                            </div>

                                            <div>
                                                <i class="icon-rotate-90"></i>
                                                <div class="mt-8">icon-rotate-90</div>
                                            </div>

                                            <div>
                                                <i class="icon-rotate-left-variant"></i>
                                                <div class="mt-8">icon-rotate-left-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-rotate-left"></i>
                                                <div class="mt-8">icon-rotate-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-rotate-right-variant"></i>
                                                <div class="mt-8">icon-rotate-right-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-rotate-right"></i>
                                                <div class="mt-8">icon-rotate-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-rounded-corner"></i>
                                                <div class="mt-8">icon-rounded-corner</div>
                                            </div>

                                            <div>
                                                <i class="icon-router-wireless"></i>
                                                <div class="mt-8">icon-router-wireless</div>
                                            </div>

                                            <div>
                                                <i class="icon-routes"></i>
                                                <div class="mt-8">icon-routes</div>
                                            </div>

                                            <div>
                                                <i class="icon-rowing"></i>
                                                <div class="mt-8">icon-rowing</div>
                                            </div>

                                            <div>
                                                <i class="icon-rss-box"></i>
                                                <div class="mt-8">icon-rss-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-rss"></i>
                                                <div class="mt-8">icon-rss</div>
                                            </div>

                                            <div>
                                                <i class="icon-ruler"></i>
                                                <div class="mt-8">icon-ruler</div>
                                            </div>

                                            <div>
                                                <i class="icon-run-fast"></i>
                                                <div class="mt-8">icon-run-fast</div>
                                            </div>

                                            <div>
                                                <i class="icon-run"></i>
                                                <div class="mt-8">icon-run</div>
                                            </div>

                                            <div>
                                                <i class="icon-sale"></i>
                                                <div class="mt-8">icon-sale</div>
                                            </div>

                                            <div>
                                                <i class="icon-satellite-variant"></i>
                                                <div class="mt-8">icon-satellite-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-satellite"></i>
                                                <div class="mt-8">icon-satellite</div>
                                            </div>

                                            <div>
                                                <i class="icon-saxophone"></i>
                                                <div class="mt-8">icon-saxophone</div>
                                            </div>

                                            <div>
                                                <i class="icon-scale-balance"></i>
                                                <div class="mt-8">icon-scale-balance</div>
                                            </div>

                                            <div>
                                                <i class="icon-scale-bathroom"></i>
                                                <div class="mt-8">icon-scale-bathroom</div>
                                            </div>

                                            <div>
                                                <i class="icon-scale"></i>
                                                <div class="mt-8">icon-scale</div>
                                            </div>

                                            <div>
                                                <i class="icon-scanner"></i>
                                                <div class="mt-8">icon-scanner</div>
                                            </div>

                                            <div>
                                                <i class="icon-school"></i>
                                                <div class="mt-8">icon-school</div>
                                            </div>

                                            <div>
                                                <i class="icon-screen-rotation-lock"></i>
                                                <div class="mt-8">icon-screen-rotation-lock</div>
                                            </div>

                                            <div>
                                                <i class="icon-screen-rotation"></i>
                                                <div class="mt-8">icon-screen-rotation</div>
                                            </div>

                                            <div>
                                                <i class="icon-screwdriver"></i>
                                                <div class="mt-8">icon-screwdriver</div>
                                            </div>

                                            <div>
                                                <i class="icon-script"></i>
                                                <div class="mt-8">icon-script</div>
                                            </div>

                                            <div>
                                                <i class="icon-sd"></i>
                                                <div class="mt-8">icon-sd</div>
                                            </div>

                                            <div>
                                                <i class="icon-seal"></i>
                                                <div class="mt-8">icon-seal</div>
                                            </div>

                                            <div>
                                                <i class="icon-search-web"></i>
                                                <div class="mt-8">icon-search-web</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-flat-angled"></i>
                                                <div class="mt-8">icon-seat-flat-angled</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-flat"></i>
                                                <div class="mt-8">icon-seat-flat</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-individual-suite"></i>
                                                <div class="mt-8">icon-seat-individual-suite</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-legroom-extra"></i>
                                                <div class="mt-8">icon-seat-legroom-extra</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-legroom-normal"></i>
                                                <div class="mt-8">icon-seat-legroom-normal</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-legroom-reduced"></i>
                                                <div class="mt-8">icon-seat-legroom-reduced</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-recline-extra"></i>
                                                <div class="mt-8">icon-seat-recline-extra</div>
                                            </div>

                                            <div>
                                                <i class="icon-seat-recline-normal"></i>
                                                <div class="mt-8">icon-seat-recline-normal</div>
                                            </div>

                                            <div>
                                                <i class="icon-security-home"></i>
                                                <div class="mt-8">icon-security-home</div>
                                            </div>

                                            <div>
                                                <i class="icon-security-network"></i>
                                                <div class="mt-8">icon-security-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-security"></i>
                                                <div class="mt-8">icon-security</div>
                                            </div>

                                            <div>
                                                <i class="icon-select-all"></i>
                                                <div class="mt-8">icon-select-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-select-inverse"></i>
                                                <div class="mt-8">icon-select-inverse</div>
                                            </div>

                                            <div>
                                                <i class="icon-select-off"></i>
                                                <div class="mt-8">icon-select-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-select"></i>
                                                <div class="mt-8">icon-select</div>
                                            </div>

                                            <div>
                                                <i class="icon-selection-off"></i>
                                                <div class="mt-8">icon-selection-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-selection"></i>
                                                <div class="mt-8">icon-selection</div>
                                            </div>

                                            <div>
                                                <i class="icon-send"></i>
                                                <div class="mt-8">icon-send</div>
                                            </div>

                                            <div>
                                                <i class="icon-serial-port"></i>
                                                <div class="mt-8">icon-serial-port</div>
                                            </div>

                                            <div>
                                                <i class="icon-server-minus"></i>
                                                <div class="mt-8">icon-server-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-server-network-off"></i>
                                                <div class="mt-8">icon-server-network-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-server-network"></i>
                                                <div class="mt-8">icon-server-network</div>
                                            </div>

                                            <div>
                                                <i class="icon-server-off"></i>
                                                <div class="mt-8">icon-server-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-server-plus"></i>
                                                <div class="mt-8">icon-server-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-server-remove"></i>
                                                <div class="mt-8">icon-server-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-server-security"></i>
                                                <div class="mt-8">icon-server-security</div>
                                            </div>

                                            <div>
                                                <i class="icon-server"></i>
                                                <div class="mt-8">icon-server</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-all"></i>
                                                <div class="mt-8">icon-set-all</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-center-right"></i>
                                                <div class="mt-8">icon-set-center-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-center"></i>
                                                <div class="mt-8">icon-set-center</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-left-center"></i>
                                                <div class="mt-8">icon-set-left-center</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-left-right"></i>
                                                <div class="mt-8">icon-set-left-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-left"></i>
                                                <div class="mt-8">icon-set-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-none"></i>
                                                <div class="mt-8">icon-set-none</div>
                                            </div>

                                            <div>
                                                <i class="icon-set-right"></i>
                                                <div class="mt-8">icon-set-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-settings-box"></i>
                                                <div class="mt-8">icon-settings-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-settings"></i>
                                                <div class="mt-8">icon-settings</div>
                                            </div>

                                            <div>
                                                <i class="icon-shape-circle-plus"></i>
                                                <div class="mt-8">icon-shape-circle-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-shape-plus"></i>
                                                <div class="mt-8">icon-shape-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-shape-polygon-plus"></i>
                                                <div class="mt-8">icon-shape-polygon-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-shape-rectangle-plus"></i>
                                                <div class="mt-8">icon-shape-rectangle-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-shape-square-plus"></i>
                                                <div class="mt-8">icon-shape-square-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-share-variant"></i>
                                                <div class="mt-8">icon-share-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-share"></i>
                                                <div class="mt-8">icon-share</div>
                                            </div>

                                            <div>
                                                <i class="icon-shield-half-full"></i>
                                                <div class="mt-8">icon-shield-half-full</div>
                                            </div>

                                            <div>
                                                <i class="icon-shield-outline"></i>
                                                <div class="mt-8">icon-shield-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-shield"></i>
                                                <div class="mt-8">icon-shield</div>
                                            </div>

                                            <div>
                                                <i class="icon-shopping-music"></i>
                                                <div class="mt-8">icon-shopping-music</div>
                                            </div>

                                            <div>
                                                <i class="icon-shopping"></i>
                                                <div class="mt-8">icon-shopping</div>
                                            </div>

                                            <div>
                                                <i class="icon-shovel-off"></i>
                                                <div class="mt-8">icon-shovel-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-shovel"></i>
                                                <div class="mt-8">icon-shovel</div>
                                            </div>

                                            <div>
                                                <i class="icon-shredder"></i>
                                                <div class="mt-8">icon-shredder</div>
                                            </div>

                                            <div>
                                                <i class="icon-shuffle-disabled"></i>
                                                <div class="mt-8">icon-shuffle-disabled</div>
                                            </div>

                                            <div>
                                                <i class="icon-shuffle-variant"></i>
                                                <div class="mt-8">icon-shuffle-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-shuffle"></i>
                                                <div class="mt-8">icon-shuffle</div>
                                            </div>

                                            <div>
                                                <i class="icon-sigma-lower"></i>
                                                <div class="mt-8">icon-sigma-lower</div>
                                            </div>

                                            <div>
                                                <i class="icon-sigma"></i>
                                                <div class="mt-8">icon-sigma</div>
                                            </div>

                                            <div>
                                                <i class="icon-sign-caution"></i>
                                                <div class="mt-8">icon-sign-caution</div>
                                            </div>

                                            <div>
                                                <i class="icon-sign-direction"></i>
                                                <div class="mt-8">icon-sign-direction</div>
                                            </div>

                                            <div>
                                                <i class="icon-sign-text"></i>
                                                <div class="mt-8">icon-sign-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal-2g"></i>
                                                <div class="mt-8">icon-signal-2g</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal-3g"></i>
                                                <div class="mt-8">icon-signal-3g</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal-4g"></i>
                                                <div class="mt-8">icon-signal-4g</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal-hspa-plus"></i>
                                                <div class="mt-8">icon-signal-hspa-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal-hspa"></i>
                                                <div class="mt-8">icon-signal-hspa</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal-off"></i>
                                                <div class="mt-8">icon-signal-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal-variant"></i>
                                                <div class="mt-8">icon-signal-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-signal"></i>
                                                <div class="mt-8">icon-signal</div>
                                            </div>

                                            <div>
                                                <i class="icon-silverware-fork"></i>
                                                <div class="mt-8">icon-silverware-fork</div>
                                            </div>

                                            <div>
                                                <i class="icon-silverware-spoon"></i>
                                                <div class="mt-8">icon-silverware-spoon</div>
                                            </div>

                                            <div>
                                                <i class="icon-silverware-variant"></i>
                                                <div class="mt-8">icon-silverware-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-silverware"></i>
                                                <div class="mt-8">icon-silverware</div>
                                            </div>

                                            <div>
                                                <i class="icon-sim-alert"></i>
                                                <div class="mt-8">icon-sim-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-sim-off"></i>
                                                <div class="mt-8">icon-sim-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-sim"></i>
                                                <div class="mt-8">icon-sim</div>
                                            </div>

                                            <div>
                                                <i class="icon-sitemap"></i>
                                                <div class="mt-8">icon-sitemap</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-backward"></i>
                                                <div class="mt-8">icon-skip-backward</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-forward"></i>
                                                <div class="mt-8">icon-skip-forward</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-next-circle-outline"></i>
                                                <div class="mt-8">icon-skip-next-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-next-circle"></i>
                                                <div class="mt-8">icon-skip-next-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-next"></i>
                                                <div class="mt-8">icon-skip-next</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-previous-circle-outline"></i>
                                                <div class="mt-8">icon-skip-previous-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-previous-circle"></i>
                                                <div class="mt-8">icon-skip-previous-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-skip-previous"></i>
                                                <div class="mt-8">icon-skip-previous</div>
                                            </div>

                                            <div>
                                                <i class="icon-skull"></i>
                                                <div class="mt-8">icon-skull</div>
                                            </div>

                                            <div>
                                                <i class="icon-skype-business"></i>
                                                <div class="mt-8">icon-skype-business</div>
                                            </div>

                                            <div>
                                                <i class="icon-skype"></i>
                                                <div class="mt-8">icon-skype</div>
                                            </div>

                                            <div>
                                                <i class="icon-slack"></i>
                                                <div class="mt-8">icon-slack</div>
                                            </div>

                                            <div>
                                                <i class="icon-sleep-off"></i>
                                                <div class="mt-8">icon-sleep-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-sleep"></i>
                                                <div class="mt-8">icon-sleep</div>
                                            </div>

                                            <div>
                                                <i class="icon-smoking-off"></i>
                                                <div class="mt-8">icon-smoking-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-smoking"></i>
                                                <div class="mt-8">icon-smoking</div>
                                            </div>

                                            <div>
                                                <i class="icon-snapchat"></i>
                                                <div class="mt-8">icon-snapchat</div>
                                            </div>

                                            <div>
                                                <i class="icon-snowflake"></i>
                                                <div class="mt-8">icon-snowflake</div>
                                            </div>

                                            <div>
                                                <i class="icon-snowman"></i>
                                                <div class="mt-8">icon-snowman</div>
                                            </div>

                                            <div>
                                                <i class="icon-soccer"></i>
                                                <div class="mt-8">icon-soccer</div>
                                            </div>

                                            <div>
                                                <i class="icon-sofa"></i>
                                                <div class="mt-8">icon-sofa</div>
                                            </div>

                                            <div>
                                                <i class="icon-solid"></i>
                                                <div class="mt-8">icon-solid</div>
                                            </div>

                                            <div>
                                                <i class="icon-sort-alphabetical"></i>
                                                <div class="mt-8">icon-sort-alphabetical</div>
                                            </div>

                                            <div>
                                                <i class="icon-sort-ascending"></i>
                                                <div class="mt-8">icon-sort-ascending</div>
                                            </div>

                                            <div>
                                                <i class="icon-sort-descending"></i>
                                                <div class="mt-8">icon-sort-descending</div>
                                            </div>

                                            <div>
                                                <i class="icon-sort-numeric"></i>
                                                <div class="mt-8">icon-sort-numeric</div>
                                            </div>

                                            <div>
                                                <i class="icon-sort-variant"></i>
                                                <div class="mt-8">icon-sort-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-sort"></i>
                                                <div class="mt-8">icon-sort</div>
                                            </div>

                                            <div>
                                                <i class="icon-soundcloud"></i>
                                                <div class="mt-8">icon-soundcloud</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-branch"></i>
                                                <div class="mt-8">icon-source-branch</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-commit-end-local"></i>
                                                <div class="mt-8">icon-source-commit-end-local</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-commit-end"></i>
                                                <div class="mt-8">icon-source-commit-end</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-commit-local"></i>
                                                <div class="mt-8">icon-source-commit-local</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-commit-next-local"></i>
                                                <div class="mt-8">icon-source-commit-next-local</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-commit-start-next-local"></i>
                                                <div class="mt-8">icon-source-commit-start-next-local</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-commit-start"></i>
                                                <div class="mt-8">icon-source-commit-start</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-commit"></i>
                                                <div class="mt-8">icon-source-commit</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-fork"></i>
                                                <div class="mt-8">icon-source-fork</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-merge"></i>
                                                <div class="mt-8">icon-source-merge</div>
                                            </div>

                                            <div>
                                                <i class="icon-source-pull"></i>
                                                <div class="mt-8">icon-source-pull</div>
                                            </div>

                                            <div>
                                                <i class="icon-speaker-off"></i>
                                                <div class="mt-8">icon-speaker-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-speaker-wireless"></i>
                                                <div class="mt-8">icon-speaker-wireless</div>
                                            </div>

                                            <div>
                                                <i class="icon-speaker"></i>
                                                <div class="mt-8">icon-speaker</div>
                                            </div>

                                            <div>
                                                <i class="icon-speedometer"></i>
                                                <div class="mt-8">icon-speedometer</div>
                                            </div>

                                            <div>
                                                <i class="icon-spellcheck"></i>
                                                <div class="mt-8">icon-spellcheck</div>
                                            </div>

                                            <div>
                                                <i class="icon-spotify"></i>
                                                <div class="mt-8">icon-spotify</div>
                                            </div>

                                            <div>
                                                <i class="icon-spotlight-beam"></i>
                                                <div class="mt-8">icon-spotlight-beam</div>
                                            </div>

                                            <div>
                                                <i class="icon-spotlight"></i>
                                                <div class="mt-8">icon-spotlight</div>
                                            </div>

                                            <div>
                                                <i class="icon-spray"></i>
                                                <div class="mt-8">icon-spray</div>
                                            </div>

                                            <div>
                                                <i class="icon-spreadsheet"></i>
                                                <div class="mt-8">icon-spreadsheet</div>
                                            </div>

                                            <div>
                                                <i class="icon-square-inc-cash"></i>
                                                <div class="mt-8">icon-square-inc-cash</div>
                                            </div>

                                            <div>
                                                <i class="icon-square-inc"></i>
                                                <div class="mt-8">icon-square-inc</div>
                                            </div>

                                            <div>
                                                <i class="icon-square-outline"></i>
                                                <div class="mt-8">icon-square-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-square-root"></i>
                                                <div class="mt-8">icon-square-root</div>
                                            </div>

                                            <div>
                                                <i class="icon-square"></i>
                                                <div class="mt-8">icon-square</div>
                                            </div>

                                            <div>
                                                <i class="icon-stackexchange"></i>
                                                <div class="mt-8">icon-stackexchange</div>
                                            </div>

                                            <div>
                                                <i class="icon-stackoverflow"></i>
                                                <div class="mt-8">icon-stackoverflow</div>
                                            </div>

                                            <div>
                                                <i class="icon-stadium"></i>
                                                <div class="mt-8">icon-stadium</div>
                                            </div>

                                            <div>
                                                <i class="icon-stairs"></i>
                                                <div class="mt-8">icon-stairs</div>
                                            </div>

                                            <div>
                                                <i class="icon-star-circle"></i>
                                                <div class="mt-8">icon-star-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-star-half"></i>
                                                <div class="mt-8">icon-star-half</div>
                                            </div>

                                            <div>
                                                <i class="icon-star-of-david"></i>
                                                <div class="mt-8">icon-star-of-david</div>
                                            </div>

                                            <div>
                                                <i class="icon-star-off"></i>
                                                <div class="mt-8">icon-star-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-star-outline"></i>
                                                <div class="mt-8">icon-star-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-star"></i>
                                                <div class="mt-8">icon-star</div>
                                            </div>

                                            <div>
                                                <i class="icon-steam"></i>
                                                <div class="mt-8">icon-steam</div>
                                            </div>

                                            <div>
                                                <i class="icon-steering"></i>
                                                <div class="mt-8">icon-steering</div>
                                            </div>

                                            <div>
                                                <i class="icon-step-backward-2"></i>
                                                <div class="mt-8">icon-step-backward-2</div>
                                            </div>

                                            <div>
                                                <i class="icon-step-backward"></i>
                                                <div class="mt-8">icon-step-backward</div>
                                            </div>

                                            <div>
                                                <i class="icon-step-forward-2"></i>
                                                <div class="mt-8">icon-step-forward-2</div>
                                            </div>

                                            <div>
                                                <i class="icon-step-forward"></i>
                                                <div class="mt-8">icon-step-forward</div>
                                            </div>

                                            <div>
                                                <i class="icon-stethoscope"></i>
                                                <div class="mt-8">icon-stethoscope</div>
                                            </div>

                                            <div>
                                                <i class="icon-sticker-emoji"></i>
                                                <div class="mt-8">icon-sticker-emoji</div>
                                            </div>

                                            <div>
                                                <i class="icon-sticker"></i>
                                                <div class="mt-8">icon-sticker</div>
                                            </div>

                                            <div>
                                                <i class="icon-stocking"></i>
                                                <div class="mt-8">icon-stocking</div>
                                            </div>

                                            <div>
                                                <i class="icon-stop-circle-outline"></i>
                                                <div class="mt-8">icon-stop-circle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-stop-circle"></i>
                                                <div class="mt-8">icon-stop-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-stop"></i>
                                                <div class="mt-8">icon-stop</div>
                                            </div>

                                            <div>
                                                <i class="icon-store-24-hour"></i>
                                                <div class="mt-8">icon-store-24-hour</div>
                                            </div>

                                            <div>
                                                <i class="icon-store"></i>
                                                <div class="mt-8">icon-store</div>
                                            </div>

                                            <div>
                                                <i class="icon-stove"></i>
                                                <div class="mt-8">icon-stove</div>
                                            </div>

                                            <div>
                                                <i class="icon-subdirectory-arrow-left"></i>
                                                <div class="mt-8">icon-subdirectory-arrow-left</div>
                                            </div>

                                            <div>
                                                <i class="icon-subdirectory-arrow-right"></i>
                                                <div class="mt-8">icon-subdirectory-arrow-right</div>
                                            </div>

                                            <div>
                                                <i class="icon-subway-variant"></i>
                                                <div class="mt-8">icon-subway-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-subway"></i>
                                                <div class="mt-8">icon-subway</div>
                                            </div>

                                            <div>
                                                <i class="icon-summit"></i>
                                                <div class="mt-8">icon-summit</div>
                                            </div>

                                            <div>
                                                <i class="icon-sunglasses"></i>
                                                <div class="mt-8">icon-sunglasses</div>
                                            </div>

                                            <div>
                                                <i class="icon-surround-sound"></i>
                                                <div class="mt-8">icon-surround-sound</div>
                                            </div>

                                            <div>
                                                <i class="icon-svg"></i>
                                                <div class="mt-8">icon-svg</div>
                                            </div>

                                            <div>
                                                <i class="icon-swap-horizontal"></i>
                                                <div class="mt-8">icon-swap-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-swap-vertical"></i>
                                                <div class="mt-8">icon-swap-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-swim"></i>
                                                <div class="mt-8">icon-swim</div>
                                            </div>

                                            <div>
                                                <i class="icon-switch"></i>
                                                <div class="mt-8">icon-switch</div>
                                            </div>

                                            <div>
                                                <i class="icon-sword-cross"></i>
                                                <div class="mt-8">icon-sword-cross</div>
                                            </div>

                                            <div>
                                                <i class="icon-sword"></i>
                                                <div class="mt-8">icon-sword</div>
                                            </div>

                                            <div>
                                                <i class="icon-sync-alert"></i>
                                                <div class="mt-8">icon-sync-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-sync-off"></i>
                                                <div class="mt-8">icon-sync-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-sync"></i>
                                                <div class="mt-8">icon-sync</div>
                                            </div>

                                            <div>
                                                <i class="icon-tab-plus"></i>
                                                <div class="mt-8">icon-tab-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-tab-unselected"></i>
                                                <div class="mt-8">icon-tab-unselected</div>
                                            </div>

                                            <div>
                                                <i class="icon-tab"></i>
                                                <div class="mt-8">icon-tab</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-column-plus-after"></i>
                                                <div class="mt-8">icon-table-column-plus-after</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-column-plus-before"></i>
                                                <div class="mt-8">icon-table-column-plus-before</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-column-remove"></i>
                                                <div class="mt-8">icon-table-column-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-column-width"></i>
                                                <div class="mt-8">icon-table-column-width</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-edit"></i>
                                                <div class="mt-8">icon-table-edit</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-large"></i>
                                                <div class="mt-8">icon-table-large</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-row-height"></i>
                                                <div class="mt-8">icon-table-row-height</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-row-plus-after"></i>
                                                <div class="mt-8">icon-table-row-plus-after</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-row-plus-before"></i>
                                                <div class="mt-8">icon-table-row-plus-before</div>
                                            </div>

                                            <div>
                                                <i class="icon-table-row-remove"></i>
                                                <div class="mt-8">icon-table-row-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-table"></i>
                                                <div class="mt-8">icon-table</div>
                                            </div>

                                            <div>
                                                <i class="icon-tablet-android"></i>
                                                <div class="mt-8">icon-tablet-android</div>
                                            </div>

                                            <div>
                                                <i class="icon-tablet-ipad"></i>
                                                <div class="mt-8">icon-tablet-ipad</div>
                                            </div>

                                            <div>
                                                <i class="icon-tablet"></i>
                                                <div class="mt-8">icon-tablet</div>
                                            </div>

                                            <div>
                                                <i class="icon-taco"></i>
                                                <div class="mt-8">icon-taco</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag-faces"></i>
                                                <div class="mt-8">icon-tag-faces</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag-heart"></i>
                                                <div class="mt-8">icon-tag-heart</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag-multiple"></i>
                                                <div class="mt-8">icon-tag-multiple</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag-outline"></i>
                                                <div class="mt-8">icon-tag-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag-plus"></i>
                                                <div class="mt-8">icon-tag-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag-remove"></i>
                                                <div class="mt-8">icon-tag-remove</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag-text-outline"></i>
                                                <div class="mt-8">icon-tag-text-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-tag"></i>
                                                <div class="mt-8">icon-tag</div>
                                            </div>

                                            <div>
                                                <i class="icon-target"></i>
                                                <div class="mt-8">icon-target</div>
                                            </div>

                                            <div>
                                                <i class="icon-taxi"></i>
                                                <div class="mt-8">icon-taxi</div>
                                            </div>

                                            <div>
                                                <i class="icon-teamviewer"></i>
                                                <div class="mt-8">icon-teamviewer</div>
                                            </div>

                                            <div>
                                                <i class="icon-telegram"></i>
                                                <div class="mt-8">icon-telegram</div>
                                            </div>

                                            <div>
                                                <i class="icon-television-guide"></i>
                                                <div class="mt-8">icon-television-guide</div>
                                            </div>

                                            <div>
                                                <i class="icon-television"></i>
                                                <div class="mt-8">icon-television</div>
                                            </div>

                                            <div>
                                                <i class="icon-temperature-celsius"></i>
                                                <div class="mt-8">icon-temperature-celsius</div>
                                            </div>

                                            <div>
                                                <i class="icon-temperature-fahrenheit"></i>
                                                <div class="mt-8">icon-temperature-fahrenheit</div>
                                            </div>

                                            <div>
                                                <i class="icon-temperature-kelvin"></i>
                                                <div class="mt-8">icon-temperature-kelvin</div>
                                            </div>

                                            <div>
                                                <i class="icon-tennis"></i>
                                                <div class="mt-8">icon-tennis</div>
                                            </div>

                                            <div>
                                                <i class="icon-tent"></i>
                                                <div class="mt-8">icon-tent</div>
                                            </div>

                                            <div>
                                                <i class="icon-terrain"></i>
                                                <div class="mt-8">icon-terrain</div>
                                            </div>

                                            <div>
                                                <i class="icon-test-tube"></i>
                                                <div class="mt-8">icon-test-tube</div>
                                            </div>

                                            <div>
                                                <i class="icon-text-shadow"></i>
                                                <div class="mt-8">icon-text-shadow</div>
                                            </div>

                                            <div>
                                                <i class="icon-text-to-speech-off"></i>
                                                <div class="mt-8">icon-text-to-speech-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-text-to-speech"></i>
                                                <div class="mt-8">icon-text-to-speech</div>
                                            </div>

                                            <div>
                                                <i class="icon-textbox"></i>
                                                <div class="mt-8">icon-textbox</div>
                                            </div>

                                            <div>
                                                <i class="icon-texture"></i>
                                                <div class="mt-8">icon-texture</div>
                                            </div>

                                            <div>
                                                <i class="icon-theater"></i>
                                                <div class="mt-8">icon-theater</div>
                                            </div>

                                            <div>
                                                <i class="icon-theme-light-dark"></i>
                                                <div class="mt-8">icon-theme-light-dark</div>
                                            </div>

                                            <div>
                                                <i class="icon-thermometer-lines"></i>
                                                <div class="mt-8">icon-thermometer-lines</div>
                                            </div>

                                            <div>
                                                <i class="icon-thermometer"></i>
                                                <div class="mt-8">icon-thermometer</div>
                                            </div>

                                            <div>
                                                <i class="icon-thumb-down-outline"></i>
                                                <div class="mt-8">icon-thumb-down-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-thumb-down"></i>
                                                <div class="mt-8">icon-thumb-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-thumb-up-outline"></i>
                                                <div class="mt-8">icon-thumb-up-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-thumb-up"></i>
                                                <div class="mt-8">icon-thumb-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-thumbs-up-down"></i>
                                                <div class="mt-8">icon-thumbs-up-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-ticket-account"></i>
                                                <div class="mt-8">icon-ticket-account</div>
                                            </div>

                                            <div>
                                                <i class="icon-ticket-confirmation"></i>
                                                <div class="mt-8">icon-ticket-confirmation</div>
                                            </div>

                                            <div>
                                                <i class="icon-ticket-percent"></i>
                                                <div class="mt-8">icon-ticket-percent</div>
                                            </div>

                                            <div>
                                                <i class="icon-ticket-star"></i>
                                                <div class="mt-8">icon-ticket-star</div>
                                            </div>

                                            <div>
                                                <i class="icon-tie"></i>
                                                <div class="mt-8">icon-tie</div>
                                            </div>

                                            <div>
                                                <i class="icon-tilde"></i>
                                                <div class="mt-8">icon-tilde</div>
                                            </div>

                                            <div>
                                                <i class="icon-tile-four"></i>
                                                <div class="mt-8">icon-tile-four</div>
                                            </div>

                                            <div>
                                                <i class="icon-timelapse"></i>
                                                <div class="mt-8">icon-timelapse</div>
                                            </div>

                                            <div>
                                                <i class="icon-timer-3"></i>
                                                <div class="mt-8">icon-timer-3</div>
                                            </div>

                                            <div>
                                                <i class="icon-timer-10"></i>
                                                <div class="mt-8">icon-timer-10</div>
                                            </div>

                                            <div>
                                                <i class="icon-timer-off"></i>
                                                <div class="mt-8">icon-timer-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-timer-sand-empty"></i>
                                                <div class="mt-8">icon-timer-sand-empty</div>
                                            </div>

                                            <div>
                                                <i class="icon-timer-sand-full"></i>
                                                <div class="mt-8">icon-timer-sand-full</div>
                                            </div>

                                            <div>
                                                <i class="icon-timer-sand"></i>
                                                <div class="mt-8">icon-timer-sand</div>
                                            </div>

                                            <div>
                                                <i class="icon-timer"></i>
                                                <div class="mt-8">icon-timer</div>
                                            </div>

                                            <div>
                                                <i class="icon-timetable"></i>
                                                <div class="mt-8">icon-timetable</div>
                                            </div>

                                            <div>
                                                <i class="icon-toggle-switch-off"></i>
                                                <div class="mt-8">icon-toggle-switch-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-toggle-switch-on"></i>
                                                <div class="mt-8">icon-toggle-switch-on</div>
                                            </div>

                                            <div>
                                                <i class="icon-tooltip-edit"></i>
                                                <div class="mt-8">icon-tooltip-edit</div>
                                            </div>

                                            <div>
                                                <i class="icon-tooltip-image"></i>
                                                <div class="mt-8">icon-tooltip-image</div>
                                            </div>

                                            <div>
                                                <i class="icon-tooltip-outline-plus"></i>
                                                <div class="mt-8">icon-tooltip-outline-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-tooltip-outline"></i>
                                                <div class="mt-8">icon-tooltip-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-tooltip-text"></i>
                                                <div class="mt-8">icon-tooltip-text</div>
                                            </div>

                                            <div>
                                                <i class="icon-tooltip"></i>
                                                <div class="mt-8">icon-tooltip</div>
                                            </div>

                                            <div>
                                                <i class="icon-tooth"></i>
                                                <div class="mt-8">icon-tooth</div>
                                            </div>

                                            <div>
                                                <i class="icon-tor"></i>
                                                <div class="mt-8">icon-tor</div>
                                            </div>

                                            <div>
                                                <i class="icon-tower-beach"></i>
                                                <div class="mt-8">icon-tower-beach</div>
                                            </div>

                                            <div>
                                                <i class="icon-tower-fire"></i>
                                                <div class="mt-8">icon-tower-fire</div>
                                            </div>

                                            <div>
                                                <i class="icon-traffic-light"></i>
                                                <div class="mt-8">icon-traffic-light</div>
                                            </div>

                                            <div>
                                                <i class="icon-train"></i>
                                                <div class="mt-8">icon-train</div>
                                            </div>

                                            <div>
                                                <i class="icon-tram"></i>
                                                <div class="mt-8">icon-tram</div>
                                            </div>

                                            <div>
                                                <i class="icon-transcribe-close"></i>
                                                <div class="mt-8">icon-transcribe-close</div>
                                            </div>

                                            <div>
                                                <i class="icon-transcribe"></i>
                                                <div class="mt-8">icon-transcribe</div>
                                            </div>

                                            <div>
                                                <i class="icon-transfer"></i>
                                                <div class="mt-8">icon-transfer</div>
                                            </div>

                                            <div>
                                                <i class="icon-transit-transfer"></i>
                                                <div class="mt-8">icon-transit-transfer</div>
                                            </div>

                                            <div>
                                                <i class="icon-translate"></i>
                                                <div class="mt-8">icon-translate</div>
                                            </div>

                                            <div>
                                                <i class="icon-trash"></i>
                                                <div class="mt-8">icon-trash</div>
                                            </div>

                                            <div>
                                                <i class="icon-treasure-chest"></i>
                                                <div class="mt-8">icon-treasure-chest</div>
                                            </div>

                                            <div>
                                                <i class="icon-tree"></i>
                                                <div class="mt-8">icon-tree</div>
                                            </div>

                                            <div>
                                                <i class="icon-trello"></i>
                                                <div class="mt-8">icon-trello</div>
                                            </div>

                                            <div>
                                                <i class="icon-trending-down"></i>
                                                <div class="mt-8">icon-trending-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-trending-neutral"></i>
                                                <div class="mt-8">icon-trending-neutral</div>
                                            </div>

                                            <div>
                                                <i class="icon-trending-up"></i>
                                                <div class="mt-8">icon-trending-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-triangle-outline"></i>
                                                <div class="mt-8">icon-triangle-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-triangle"></i>
                                                <div class="mt-8">icon-triangle</div>
                                            </div>

                                            <div>
                                                <i class="icon-trophy-outline"></i>
                                                <div class="mt-8">icon-trophy-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-trophy-variant-outline"></i>
                                                <div class="mt-8">icon-trophy-variant-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-truck-delivery"></i>
                                                <div class="mt-8">icon-truck-delivery</div>
                                            </div>

                                            <div>
                                                <i class="icon-truck-fast"></i>
                                                <div class="mt-8">icon-truck-fast</div>
                                            </div>

                                            <div>
                                                <i class="icon-truck-trailer"></i>
                                                <div class="mt-8">icon-truck-trailer</div>
                                            </div>

                                            <div>
                                                <i class="icon-truck"></i>
                                                <div class="mt-8">icon-truck</div>
                                            </div>

                                            <div>
                                                <i class="icon-tshirt-crew"></i>
                                                <div class="mt-8">icon-tshirt-crew</div>
                                            </div>

                                            <div>
                                                <i class="icon-tshirt-v"></i>
                                                <div class="mt-8">icon-tshirt-v</div>
                                            </div>

                                            <div>
                                                <i class="icon-tumblr-reblog"></i>
                                                <div class="mt-8">icon-tumblr-reblog</div>
                                            </div>

                                            <div>
                                                <i class="icon-tumblr"></i>
                                                <div class="mt-8">icon-tumblr</div>
                                            </div>

                                            <div>
                                                <i class="icon-tune-vertical"></i>
                                                <div class="mt-8">icon-tune-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-tune"></i>
                                                <div class="mt-8">icon-tune</div>
                                            </div>

                                            <div>
                                                <i class="icon-twitch"></i>
                                                <div class="mt-8">icon-twitch</div>
                                            </div>

                                            <div>
                                                <i class="icon-twitter-box"></i>
                                                <div class="mt-8">icon-twitter-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-twitter-circle"></i>
                                                <div class="mt-8">icon-twitter-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-twitter-retweet"></i>
                                                <div class="mt-8">icon-twitter-retweet</div>
                                            </div>

                                            <div>
                                                <i class="icon-twitter"></i>
                                                <div class="mt-8">icon-twitter</div>
                                            </div>

                                            <div>
                                                <i class="icon-uber"></i>
                                                <div class="mt-8">icon-uber</div>
                                            </div>

                                            <div>
                                                <i class="icon-ubuntu"></i>
                                                <div class="mt-8">icon-ubuntu</div>
                                            </div>

                                            <div>
                                                <i class="icon-umbraco"></i>
                                                <div class="mt-8">icon-umbraco</div>
                                            </div>

                                            <div>
                                                <i class="icon-umbrella-outline"></i>
                                                <div class="mt-8">icon-umbrella-outline</div>
                                            </div>

                                            <div>
                                                <i class="icon-umbrella"></i>
                                                <div class="mt-8">icon-umbrella</div>
                                            </div>

                                            <div>
                                                <i class="icon-undo-variant"></i>
                                                <div class="mt-8">icon-undo-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-undo"></i>
                                                <div class="mt-8">icon-undo</div>
                                            </div>

                                            <div>
                                                <i class="icon-unfold-less-horizontal"></i>
                                                <div class="mt-8">icon-unfold-less-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-unfold-less-vertical"></i>
                                                <div class="mt-8">icon-unfold-less-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-unfold-more-horizontal"></i>
                                                <div class="mt-8">icon-unfold-more-horizontal</div>
                                            </div>

                                            <div>
                                                <i class="icon-unfold-more-vertical"></i>
                                                <div class="mt-8">icon-unfold-more-vertical</div>
                                            </div>

                                            <div>
                                                <i class="icon-ungroup"></i>
                                                <div class="mt-8">icon-ungroup</div>
                                            </div>

                                            <div>
                                                <i class="icon-unity"></i>
                                                <div class="mt-8">icon-unity</div>
                                            </div>

                                            <div>
                                                <i class="icon-untappd"></i>
                                                <div class="mt-8">icon-untappd</div>
                                            </div>

                                            <div>
                                                <i class="icon-update"></i>
                                                <div class="mt-8">icon-update</div>
                                            </div>

                                            <div>
                                                <i class="icon-upload"></i>
                                                <div class="mt-8">icon-upload</div>
                                            </div>

                                            <div>
                                                <i class="icon-usb"></i>
                                                <div class="mt-8">icon-usb</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-arrange-above"></i>
                                                <div class="mt-8">icon-vector-arrange-above</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-arrange-below"></i>
                                                <div class="mt-8">icon-vector-arrange-below</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-circle-variant"></i>
                                                <div class="mt-8">icon-vector-circle-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-circle"></i>
                                                <div class="mt-8">icon-vector-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-combine"></i>
                                                <div class="mt-8">icon-vector-combine</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-curve"></i>
                                                <div class="mt-8">icon-vector-curve</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-difference-ab"></i>
                                                <div class="mt-8">icon-vector-difference-ab</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-difference-ba"></i>
                                                <div class="mt-8">icon-vector-difference-ba</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-difference"></i>
                                                <div class="mt-8">icon-vector-difference</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-intersection"></i>
                                                <div class="mt-8">icon-vector-intersection</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-line"></i>
                                                <div class="mt-8">icon-vector-line</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-point"></i>
                                                <div class="mt-8">icon-vector-point</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-polygon"></i>
                                                <div class="mt-8">icon-vector-polygon</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-polyline"></i>
                                                <div class="mt-8">icon-vector-polyline</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-radius"></i>
                                                <div class="mt-8">icon-vector-radius</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-rectangle"></i>
                                                <div class="mt-8">icon-vector-rectangle</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-selection"></i>
                                                <div class="mt-8">icon-vector-selection</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-square"></i>
                                                <div class="mt-8">icon-vector-square</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-triangle"></i>
                                                <div class="mt-8">icon-vector-triangle</div>
                                            </div>

                                            <div>
                                                <i class="icon-vector-union"></i>
                                                <div class="mt-8">icon-vector-union</div>
                                            </div>

                                            <div>
                                                <i class="icon-verified"></i>
                                                <div class="mt-8">icon-verified</div>
                                            </div>

                                            <div>
                                                <i class="icon-vibration"></i>
                                                <div class="mt-8">icon-vibration</div>
                                            </div>

                                            <div>
                                                <i class="icon-video-off"></i>
                                                <div class="mt-8">icon-video-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-video-switch"></i>
                                                <div class="mt-8">icon-video-switch</div>
                                            </div>

                                            <div>
                                                <i class="icon-video"></i>
                                                <div class="mt-8">icon-video</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-agenda"></i>
                                                <div class="mt-8">icon-view-agenda</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-array"></i>
                                                <div class="mt-8">icon-view-array</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-carousel"></i>
                                                <div class="mt-8">icon-view-carousel</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-column"></i>
                                                <div class="mt-8">icon-view-column</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-dashboard"></i>
                                                <div class="mt-8">icon-view-dashboard</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-day"></i>
                                                <div class="mt-8">icon-view-day</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-headline"></i>
                                                <div class="mt-8">icon-view-headline</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-list"></i>
                                                <div class="mt-8">icon-view-list</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-module"></i>
                                                <div class="mt-8">icon-view-module</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-parallel"></i>
                                                <div class="mt-8">icon-view-parallel</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-quilt"></i>
                                                <div class="mt-8">icon-view-quilt</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-sequential"></i>
                                                <div class="mt-8">icon-view-sequential</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-stream"></i>
                                                <div class="mt-8">icon-view-stream</div>
                                            </div>

                                            <div>
                                                <i class="icon-view-week"></i>
                                                <div class="mt-8">icon-view-week</div>
                                            </div>

                                            <div>
                                                <i class="icon-vimeo"></i>
                                                <div class="mt-8">icon-vimeo</div>
                                            </div>

                                            <div>
                                                <i class="icon-vine"></i>
                                                <div class="mt-8">icon-vine</div>
                                            </div>

                                            <div>
                                                <i class="icon-violin"></i>
                                                <div class="mt-8">icon-violin</div>
                                            </div>

                                            <div>
                                                <i class="icon-visualstudio"></i>
                                                <div class="mt-8">icon-visualstudio</div>
                                            </div>

                                            <div>
                                                <i class="icon-vk-box"></i>
                                                <div class="mt-8">icon-vk-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-vk-circle"></i>
                                                <div class="mt-8">icon-vk-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-vk"></i>
                                                <div class="mt-8">icon-vk</div>
                                            </div>

                                            <div>
                                                <i class="icon-vlc"></i>
                                                <div class="mt-8">icon-vlc</div>
                                            </div>

                                            <div>
                                                <i class="icon-voice"></i>
                                                <div class="mt-8">icon-voice</div>
                                            </div>

                                            <div>
                                                <i class="icon-voicemail"></i>
                                                <div class="mt-8">icon-voicemail</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume-high"></i>
                                                <div class="mt-8">icon-volume-high</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume-low"></i>
                                                <div class="mt-8">icon-volume-low</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume-medium"></i>
                                                <div class="mt-8">icon-volume-medium</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume-minus"></i>
                                                <div class="mt-8">icon-volume-minus</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume-mute"></i>
                                                <div class="mt-8">icon-volume-mute</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume-off"></i>
                                                <div class="mt-8">icon-volume-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume-plus"></i>
                                                <div class="mt-8">icon-volume-plus</div>
                                            </div>

                                            <div>
                                                <i class="icon-volume"></i>
                                                <div class="mt-8">icon-volume</div>
                                            </div>

                                            <div>
                                                <i class="icon-vpn"></i>
                                                <div class="mt-8">icon-vpn</div>
                                            </div>

                                            <div>
                                                <i class="icon-walk"></i>
                                                <div class="mt-8">icon-walk</div>
                                            </div>

                                            <div>
                                                <i class="icon-wallet-giftcard"></i>
                                                <div class="mt-8">icon-wallet-giftcard</div>
                                            </div>

                                            <div>
                                                <i class="icon-wallet-membership"></i>
                                                <div class="mt-8">icon-wallet-membership</div>
                                            </div>

                                            <div>
                                                <i class="icon-wallet-travel"></i>
                                                <div class="mt-8">icon-wallet-travel</div>
                                            </div>

                                            <div>
                                                <i class="icon-wallet"></i>
                                                <div class="mt-8">icon-wallet</div>
                                            </div>

                                            <div>
                                                <i class="icon-wan"></i>
                                                <div class="mt-8">icon-wan</div>
                                            </div>

                                            <div>
                                                <i class="icon-washing-machine"></i>
                                                <div class="mt-8">icon-washing-machine</div>
                                            </div>

                                            <div>
                                                <i class="icon-watch-export"></i>
                                                <div class="mt-8">icon-watch-export</div>
                                            </div>

                                            <div>
                                                <i class="icon-watch-import"></i>
                                                <div class="mt-8">icon-watch-import</div>
                                            </div>

                                            <div>
                                                <i class="icon-watch-vibrate"></i>
                                                <div class="mt-8">icon-watch-vibrate</div>
                                            </div>

                                            <div>
                                                <i class="icon-watch"></i>
                                                <div class="mt-8">icon-watch</div>
                                            </div>

                                            <div>
                                                <i class="icon-water-off"></i>
                                                <div class="mt-8">icon-water-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-water-percent"></i>
                                                <div class="mt-8">icon-water-percent</div>
                                            </div>

                                            <div>
                                                <i class="icon-water-pump"></i>
                                                <div class="mt-8">icon-water-pump</div>
                                            </div>

                                            <div>
                                                <i class="icon-water"></i>
                                                <div class="mt-8">icon-water</div>
                                            </div>

                                            <div>
                                                <i class="icon-watermark"></i>
                                                <div class="mt-8">icon-watermark</div>
                                            </div>

                                            <div>
                                                <i class="icon-waves"></i>
                                                <div class="mt-8">icon-waves</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-cloudy"></i>
                                                <div class="mt-8">icon-weather-cloudy</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-fog"></i>
                                                <div class="mt-8">icon-weather-fog</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-hail"></i>
                                                <div class="mt-8">icon-weather-hail</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-lightning-rainy"></i>
                                                <div class="mt-8">icon-weather-lightning-rainy</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-lightning"></i>
                                                <div class="mt-8">icon-weather-lightning</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-night"></i>
                                                <div class="mt-8">icon-weather-night</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-partlycloudy"></i>
                                                <div class="mt-8">icon-weather-partlycloudy</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-pouring"></i>
                                                <div class="mt-8">icon-weather-pouring</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-rainy"></i>
                                                <div class="mt-8">icon-weather-rainy</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-snowy-rainy"></i>
                                                <div class="mt-8">icon-weather-snowy-rainy</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-snowy"></i>
                                                <div class="mt-8">icon-weather-snowy</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-sunny"></i>
                                                <div class="mt-8">icon-weather-sunny</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-sunset-down"></i>
                                                <div class="mt-8">icon-weather-sunset-down</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-sunset-up"></i>
                                                <div class="mt-8">icon-weather-sunset-up</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-sunset"></i>
                                                <div class="mt-8">icon-weather-sunset</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-windy-variant"></i>
                                                <div class="mt-8">icon-weather-windy-variant</div>
                                            </div>

                                            <div>
                                                <i class="icon-weather-windy"></i>
                                                <div class="mt-8">icon-weather-windy</div>
                                            </div>

                                            <div>
                                                <i class="icon-web"></i>
                                                <div class="mt-8">icon-web</div>
                                            </div>

                                            <div>
                                                <i class="icon-webcam"></i>
                                                <div class="mt-8">icon-webcam</div>
                                            </div>

                                            <div>
                                                <i class="icon-webhook"></i>
                                                <div class="mt-8">icon-webhook</div>
                                            </div>

                                            <div>
                                                <i class="icon-webpack"></i>
                                                <div class="mt-8">icon-webpack</div>
                                            </div>

                                            <div>
                                                <i class="icon-wechat"></i>
                                                <div class="mt-8">icon-wechat</div>
                                            </div>

                                            <div>
                                                <i class="icon-weight-kilogram"></i>
                                                <div class="mt-8">icon-weight-kilogram</div>
                                            </div>

                                            <div>
                                                <i class="icon-weight"></i>
                                                <div class="mt-8">icon-weight</div>
                                            </div>

                                            <div>
                                                <i class="icon-whatsapp"></i>
                                                <div class="mt-8">icon-whatsapp</div>
                                            </div>

                                            <div>
                                                <i class="icon-wheelchair-accessibility"></i>
                                                <div class="mt-8">icon-wheelchair-accessibility</div>
                                            </div>

                                            <div>
                                                <i class="icon-white-balance-auto"></i>
                                                <div class="mt-8">icon-white-balance-auto</div>
                                            </div>

                                            <div>
                                                <i class="icon-white-balance-incandescent"></i>
                                                <div class="mt-8">icon-white-balance-incandescent</div>
                                            </div>

                                            <div>
                                                <i class="icon-white-balance-irradescent"></i>
                                                <div class="mt-8">icon-white-balance-irradescent</div>
                                            </div>

                                            <div>
                                                <i class="icon-white-balance-sunny"></i>
                                                <div class="mt-8">icon-white-balance-sunny</div>
                                            </div>

                                            <div>
                                                <i class="icon-widgets"></i>
                                                <div class="mt-8">icon-widgets</div>
                                            </div>

                                            <div>
                                                <i class="icon-wifi-off"></i>
                                                <div class="mt-8">icon-wifi-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-wifi"></i>
                                                <div class="mt-8">icon-wifi</div>
                                            </div>

                                            <div>
                                                <i class="icon-wii"></i>
                                                <div class="mt-8">icon-wii</div>
                                            </div>

                                            <div>
                                                <i class="icon-wiiu"></i>
                                                <div class="mt-8">icon-wiiu</div>
                                            </div>

                                            <div>
                                                <i class="icon-wikipedia"></i>
                                                <div class="mt-8">icon-wikipedia</div>
                                            </div>

                                            <div>
                                                <i class="icon-window-close"></i>
                                                <div class="mt-8">icon-window-close</div>
                                            </div>

                                            <div>
                                                <i class="icon-window-closed"></i>
                                                <div class="mt-8">icon-window-closed</div>
                                            </div>

                                            <div>
                                                <i class="icon-window-maximize"></i>
                                                <div class="mt-8">icon-window-maximize</div>
                                            </div>

                                            <div>
                                                <i class="icon-window-minimize"></i>
                                                <div class="mt-8">icon-window-minimize</div>
                                            </div>

                                            <div>
                                                <i class="icon-window-open"></i>
                                                <div class="mt-8">icon-window-open</div>
                                            </div>

                                            <div>
                                                <i class="icon-window-restore"></i>
                                                <div class="mt-8">icon-window-restore</div>
                                            </div>

                                            <div>
                                                <i class="icon-windows"></i>
                                                <div class="mt-8">icon-windows</div>
                                            </div>

                                            <div>
                                                <i class="icon-wordpress"></i>
                                                <div class="mt-8">icon-wordpress</div>
                                            </div>

                                            <div>
                                                <i class="icon-worker"></i>
                                                <div class="mt-8">icon-worker</div>
                                            </div>

                                            <div>
                                                <i class="icon-wrench"></i>
                                                <div class="mt-8">icon-wrench</div>
                                            </div>

                                            <div>
                                                <i class="icon-wunderlist"></i>
                                                <div class="mt-8">icon-wunderlist</div>
                                            </div>

                                            <div>
                                                <i class="icon-xaml"></i>
                                                <div class="mt-8">icon-xaml</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller-battery-alert"></i>
                                                <div class="mt-8">icon-xbox-controller-battery-alert</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller-battery-empty"></i>
                                                <div class="mt-8">icon-xbox-controller-battery-empty</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller-battery-full"></i>
                                                <div class="mt-8">icon-xbox-controller-battery-full</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller-battery-low"></i>
                                                <div class="mt-8">icon-xbox-controller-battery-low</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller-battery-medium"></i>
                                                <div class="mt-8">icon-xbox-controller-battery-medium</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller-battery-unknown"></i>
                                                <div class="mt-8">icon-xbox-controller-battery-unknown</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller-off"></i>
                                                <div class="mt-8">icon-xbox-controller-off</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox-controller"></i>
                                                <div class="mt-8">icon-xbox-controller</div>
                                            </div>

                                            <div>
                                                <i class="icon-xbox"></i>
                                                <div class="mt-8">icon-xbox</div>
                                            </div>

                                            <div>
                                                <i class="icon-xda"></i>
                                                <div class="mt-8">icon-xda</div>
                                            </div>

                                            <div>
                                                <i class="icon-xing-box"></i>
                                                <div class="mt-8">icon-xing-box</div>
                                            </div>

                                            <div>
                                                <i class="icon-xing-circle"></i>
                                                <div class="mt-8">icon-xing-circle</div>
                                            </div>

                                            <div>
                                                <i class="icon-xing"></i>
                                                <div class="mt-8">icon-xing</div>
                                            </div>

                                            <div>
                                                <i class="icon-xml"></i>
                                                <div class="mt-8">icon-xml</div>
                                            </div>

                                            <div>
                                                <i class="icon-yammer"></i>
                                                <div class="mt-8">icon-yammer</div>
                                            </div>

                                            <div>
                                                <i class="icon-yeast"></i>
                                                <div class="mt-8">icon-yeast</div>
                                            </div>

                                            <div>
                                                <i class="icon-yelp"></i>
                                                <div class="mt-8">icon-yelp</div>
                                            </div>

                                            <div>
                                                <i class="icon-yin-yang"></i>
                                                <div class="mt-8">icon-yin-yang</div>
                                            </div>

                                            <div>
                                                <i class="icon-youtube-play"></i>
                                                <div class="mt-8">icon-youtube-play</div>
                                            </div>

                                            <div>
                                                <i class="icon-youtube"></i>
                                                <div class="mt-8">icon-youtube</div>
                                            </div>

                                            <div>
                                                <i class="icon-zip-box"></i>
                                                <div class="mt-8">icon-zip-box</div>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>
						</div>