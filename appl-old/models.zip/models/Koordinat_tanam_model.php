<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Koordinat_tanam_model extends CI_Model{

}